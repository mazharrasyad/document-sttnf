Author :
Muhammad Azhar Rasyad
0110217029
Teknik Informatika 1
Kelas Pagi
Semester 1
Sekolah Tinggi Teknologi Terpadu Nurul Fikri

Program :
Matematika Diskrit - PBB Teori Euclidean
Program Mencari Nilai PBB Teori Euclidean
Bahasa Pemrograman C++
Untuk Sistem Operasi Windows dan Linux
