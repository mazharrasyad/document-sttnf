// Program Contoh operator reference
#include <iostream>
using namespace std;

int main()
{
    int nAngka = 0; // deklarasi nAngka sekaligus inisiasi nAngka dengan 0
    int *pAngka; // deklarasi pointer pAngka
    pAngka = &nAngka; // pAngka menyimpan alamat nAngka
    cout << "Nilai dari nAngka adalah: " << nAngka << endl
         << "Nilai dari pAngka adalah: " << pAngka << endl
         << "Nilai yang ditunjuk oleh pAngka adalah: " << *pAngka
         << endl << endl;
         
    *pAngka = 2; // pak pos mengantarkan 2 ke alamat yang ditunjuk oleh pAngka
    
    cout << "Nilai dari nAngka adalah: " << nAngka << endl
         << "Nilai dari pAngka adalah: " << pAngka << endl
         << "Nilai yang ditunjuk oleh pAngka adalah: " << *pAngka << endl;
    
    system("PAUSE");
    return 0;
}
