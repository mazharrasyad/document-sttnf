// Program Contoh operator dereference
#include <iostream>
using namespace std;

int main()
{
    int a;
    int *b;
    a = 2; // variabel a berisi nilai 2
    b = &a; // variabel b berisi alamat variabel a
    cout << "Nilai variabel a adalah: " << a << endl
         << "Alamat variabel a adalah " << &a << endl
         << "Nilai variabel b adalah: " << b << endl;
         
    system("PAUSE");
    return 0;
}
