// Program Membaca Isi File
#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    FILE *teksfile;
    char penampung[256]; // Membuat variabel penampung untuk  
                         // menampung isi dari file
    teksfile = fopen("C://bootmgr", "r");
    
    if(teksfile != NULL) // jika file bisa dibuka
    {
        fgets(penampung, 256, teksfile);
        cout << penampung << endl;
    }
    else
    {
        cout << "file tidak bisa dibuka" << endl;
        fclose(teksfile);
    }
    return 0;
}
