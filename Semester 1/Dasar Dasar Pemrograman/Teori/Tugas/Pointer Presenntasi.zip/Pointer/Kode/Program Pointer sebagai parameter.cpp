// Program Pointer sebagai parameter
#include <iostream>
using namespace std;

void PertambahanNilai(int *Pertambahan)
{
     *Pertambahan += 10;
}

int main()
{
    int nilai = 32;
    cout << "Nilai nNilai adalah: " << nilai << endl;
    PertambahanNilai(&nilai);
    
    cout << "Nilai nNilai sekarang adalah: " << nilai << endl;
}
