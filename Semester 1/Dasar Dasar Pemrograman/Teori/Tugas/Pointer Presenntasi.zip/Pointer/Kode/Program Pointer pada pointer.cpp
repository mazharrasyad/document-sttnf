// Program Pointer pada pointer
#include <iostream>
using namespace std;

int main()
{
    int a;
    int *b;
    int **c;
    
    a = 32; // a bernilai 32
    b = &a; // b bernilai alamat a
    c = &b; // c bernilai alamat b
    
    cout << "Nilai a adalah: " << a << endl
         << "Nilai b adalah: " << b << endl
         << "Nilai c adalah: " << c << endl
         << "============================" << endl
         << "Nilai *b adalah: " << *b << endl
         << "Nilai *c adalah: " << *c << endl
         << "============================" << endl
         << "Nilai **c adalah :" << **c << endl
         << endl;
    
    system("PAUSE");
    return 0;
}
