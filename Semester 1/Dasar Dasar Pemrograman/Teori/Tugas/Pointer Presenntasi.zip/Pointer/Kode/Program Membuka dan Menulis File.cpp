// Program Membuka dan Menulis FIle
#include <cstdio>
#include <iostream>
using namespace std;

int main()
{
    FILE *teksfile;
    teksfile = fopen("C://filenya.txt", "w");
    fputs("ini adalah string\nyang akan dimasukkan", teksfile);
    fclose(teksfile);
    return 0;
}
