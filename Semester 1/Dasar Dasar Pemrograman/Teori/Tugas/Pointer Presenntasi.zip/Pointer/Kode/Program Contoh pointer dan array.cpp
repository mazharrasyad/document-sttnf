// Program Contoh pointer dan array
#include <iostream>
using namespace std;

int main()
{
    int *pAngka;
    int nAngka[5];
    
    pAngka = nAngka;
    nAngka[0] = 1; // memasukkan nilai 1 kedalam nAngka[0]
    cout << "Nilai nAngka[0] adalah " << nAngka[0] << endl
         << "Nilai *pAngka adalah " << *pAngka << endl
         << "Nilai pAngka adalah " << pAngka << endl << endl;
         
    pAngka++; // menambahkan address pAngka sebanyak 1 int    
    *pAngka = 3; // memberi nilai kepada variabel yang ditunjuk oleh *pArray dengan nilai 3
    cout << "Nilai nAngka[1] adalah " << nAngka[1] << endl
         << "Nilai *pAngka adalah " << *pAngka << endl
         << "Nilai pAngka sekarang adalah " << pAngka << endl << endl;
         
    pAngka = nAngka; // mengembalikan address pada pAngka menunjuk kembali pada elemen pertama
    
    nAngka[2] = 43;
    
    cout << "Nilai nAngka[2] adalah " << nAngka[2] << endl
         << "Nilai *(pAngka+2) adalah " << *(pAngka+2) << endl
         << "Nilai pAngka+2 sekarang adalah " << pAngka+2 << endl << endl;
    
    
    system("PAUSE");
    return 0;
}
