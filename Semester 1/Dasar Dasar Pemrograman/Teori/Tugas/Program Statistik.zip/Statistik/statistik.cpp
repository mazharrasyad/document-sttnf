#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
	int i,j,k,l,m,n;
	int jumlah,jumlah1,jumlah2,jumlah3,urutan,median1,median2,median3,q11,q22,q33;
	int banyak[0],modus[1000];
	float rata1,rata2,varian1,varian2,varian3;
	float rata, median, varian, simbak, q1, q2, q3;

	cout << "Program Statistik" << endl << endl;

	// Memasukkan Jumlah Data 
	cout << "Masukkan Jumlah Mahasiswa = ";
	cin >> jumlah;
	cout << endl;

	// Memasukkan Data
	int nilai[jumlah];
	rata1 = jumlah;
	jumlah1 = jumlah;
	jumlah2 = jumlah;
	jumlah3 = jumlah;
	for (i = 0; i < jumlah; i++)
	{
		cout << "Masukkan Nilai Mahasiswa " << (i+1) << " = ";
		cin >> nilai[i];
	}

	// Mencari Rata - Rata
	rata2 = 0;
	for (i = 0; i < jumlah; i++)
	{
		rata2 = rata2 + nilai[i];
	}	
	rata = rata2 / rata1;

	// Mengurutkan Data
	for(j = 1; j < jumlah; j++)
	{
		for(k = 0; k < jumlah-j; k++)
		{
			if(nilai[k] > nilai[k+1])
			{
				urutan = nilai[k];
				nilai[k] = nilai[k+1];
				nilai[k+1] = urutan;
			}
		}
	}
	cout << endl << "Data = ";
	for(i = 0; i < jumlah; i++)
	{
		cout << " " << nilai[i];
	}
	cout << endl;

	// Mencari Median
	median1 = jumlah % 2;
	if (median1 == 0)
	{
		median2 = jumlah / 2;	
		median3 = median1 + 1;
		median = (float(nilai[median2] + nilai[median3])) / 2;
	}
	else
	{
		median2 = jumlah / 2;
		median3 = median1 + 1;
		median = nilai[median2];
	}

	// Mencari Modus
	for(i = 0; i < jumlah1; i++)
	{
		banyak[i] = 0;
		for(m = 0; m < jumlah1; m++)
		{
			if(nilai[i] == nilai[m])
			{
				banyak[i]++;
			}
		}
	}

	n = 1;
	for(i = 0; i < jumlah2; i++)
	{
		if(banyak[i] > n)
		{
			n = banyak[i];
		}
	}

	l = 0;
	for(i = 0; i < jumlah2; i++)
	{
		if(l == 0)
		{
			modus[l] = 0;
		}	
		else
		{
			modus[l] = modus[l-1];
		}

		if(banyak[i] == n)
		{
			if(nilai[i] != modus[l])
			{
				modus[l] = nilai[i];
				l++;
			}
		}
	}

	if (l == 0)
	{
		cout << "\nModus = Tidak Ada" << endl;
	}
	else if (l == 1)
	{
		cout << "\nModus = ";
		for(i = 0; i < l; i++)
		{
			cout << modus[i] << endl;
		}
	}
	else
	{
		cout << "\nModus = Tidak Ada" << endl;
	}

	// Mencari Varian
	varian1 = 0;
	varian2 = 0;
	for(i = 0; i < jumlah3; i++)
	{
		varian1 = varian1 + nilai[i];
	}
	for(i = 0; i < jumlah3; i++)
	{
		varian2 = varian2 + (nilai[i] * nilai[i]);
	}	
	varian1 = varian1 * varian1;
	varian3 = jumlah3 - 1;
	varian = ((jumlah3 * varian2) - varian1) / (jumlah3 * varian3);
	
	// Mencari Simpangan Baku
	simbak = sqrt(varian);

	// Mencari Kuartil 1
	q11 = 1 * (jumlah3 + 1) / 4;
	q11 -= 1;
	q1 = nilai[q11];

	// Mencari Kuartil 2
	q22 = 2 * (jumlah3 + 1) / 4;
	q22 -= 1;
	q2 = nilai[q22];

	// Mencari Kuartil 3
	q33 = 3 * (jumlah3 + 1) / 4;
	q33 -= 1;
	q3 = nilai[q33];

	cout << "Median = " << median << endl;
	cout << "Quartil 1 = " << q1 << endl;
	cout << "Quartil 2 = " << q2 << endl;
	cout << "Quartil 3 = " << q3 << endl;
	cout << setiosflags(ios::fixed);
	cout << "Rata - Rata = " << setprecision(2) << rata << endl;
	cout << "Varian = " << setprecision(2) << varian << endl;
	cout << "Simpangan Baku = " << setprecision(2) << simbak << endl;

	return 0;
}