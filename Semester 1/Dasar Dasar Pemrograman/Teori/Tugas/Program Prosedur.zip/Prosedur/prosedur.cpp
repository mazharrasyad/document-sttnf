#include <iostream>

using namespace std;

float jari_jari, luas;

void luas_lingkaran (float jari_jari);

int main ()
{
	cout << "Program Menghitung Luas Lingkaran" << endl << endl;
	cout << "Masukkan Jari - Jari Lingkaran = ";
	cin >> jari_jari;

	luas_lingkaran(jari_jari);
}

void luas_lingkaran (float jari_jari)
{
	luas = 3.14 * jari_jari * jari_jari;
	cout << "Hasil dari luas lingkaran = " << luas << endl;
}