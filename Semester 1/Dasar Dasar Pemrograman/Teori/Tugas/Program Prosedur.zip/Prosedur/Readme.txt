Muhammad Azhar Rasyad
0110217029
Teknik Informatika 1
Dasar - Dasar Pemrograman
Sekolah Tinggi Teknologi Terpadu Nurul Fikri