#include <iostream>

using namespace std;

struct data 
{
	string user;
	string pass;
	int saldo;
} nasabah[2];

int pilihan_login,pilihan_utama,pilihan_ulang;
string nama,sandi;
int uang,jumlah_uang;	

void cek_saldo ();
void menabung ();
void transfer ();

int main ()
{
	nasabah[0].user = "azhar";
	nasabah[0].pass = "rasyad";
	nasabah[0].saldo = 50000;
	nasabah[1].user = "sholihin";
	nasabah[1].pass = "sholih";
	nasabah[1].saldo = 100000;

	menu_login:
	cout << "\n=========== MENU LOGIN ============";
	cout << "\n\n1. Login";
	cout << "\n2. Keluar";
	cout << "\n\nKetikkan Pilihan = "; cin >> pilihan_login;
	cout << "\n===================================\n";

	switch(pilihan_login)
	{
		case 1 :
			cout << "\nMasukkan Username : ";	
			cin >> nama;
			if(nama == nasabah[0].user || nama == nasabah[1].user)
			{	
				cout << "Masukkan Password : ";	
				cin >> sandi;
				if(sandi == nasabah[0].pass || sandi == nasabah[1].pass)
				{
					menu_utama:
					cout << "\n========== MENU ATM SEDERHANA ==========";
					cout << "\n\n1. Cek uang";
					cout << "\n2. Menabung";
					cout << "\n3. Transfer";
					cout << "\n4. Logout";
					cout << "\n\nKetikkan Pilihan = "; cin >> pilihan_utama;
					cout << "\n========================================\n";
					switch(pilihan_utama)
					{
						case 1 :
							cek_saldo();
							goto menu_utama;

						case 2 :
							menabung();
							goto menu_utama;
							
						case 3 :
							transfer();
							goto menu_utama;

						case 4 :
                  			goto menu_login;
                  		
						default :		
							cout << "\nPilihan Tidak Ada Periksa Menu Pilihan\n";
					    	goto menu_utama;
					}
				}
				else
				{
					cout << endl << "Password Anda Salah !\n"; 
					goto menu_login;
				}
			}
			else
			{
				cout << endl << "Username Anda Salah !\n";
				goto menu_login;
			}

		case 2 :
      		return 0;

		default :
			cout << "\nPilihan Tidak Ada Periksa Menu Pilihan\n";
    		goto menu_login;

	}
}

void cek_saldo ()
{
	if (nama == nasabah[0].user)
	{
		uang = nasabah[0].saldo;
	}
	else if (nama == nasabah[1].user)
	{
		uang = nasabah[1].saldo;
	}

	cout << "\n========================================\n";
	cout << "Total Saldo Anda Rp " << uang;
	cout << "\n========================================\n";
}

void menabung ()
{	
	do
	{
		cout << "\n========================================\n";
		cout << "Masukkan Jumlah Uang Anda Untuk DiTabung";
		cout << "\nRp "; cin >> jumlah_uang;
		cout << "========================================\n";

		if (nama == nasabah[0].user)
		{
			nasabah[0].saldo = nasabah[0].saldo + jumlah_uang;
		}
		else if (nama == nasabah[1].user)
		{
			nasabah[1].saldo = nasabah[1].saldo + jumlah_uang;
		}

		cout << "\n========================================\n";
		cout << "Apakah Anda Ingin Menabung Lagi ? ";
		cout << "\n1. Ya";
		cout << "\n2. Tidak";
		cout << "\n\nKetikkan Pilihan = "; cin >> pilihan_ulang;
		cout << "========================================\n";
	}
	while (pilihan_ulang == 1);
}

void transfer ()
{
	do
	{
		cout << "\n========================================\n";
		cout << "Masukkan Jumlah Uang Anda Untuk DiTransfer";
		cout << "\nRp "; cin >> jumlah_uang;
		cout << "========================================\n";

		if (nama == nasabah[0].user)
		{
			if (nasabah[0].saldo < jumlah_uang)
			{
				cout << "\nSaldo Anda Tidak Cukup !\n";
			}
			else
			{
				nasabah[0].saldo = nasabah[0].saldo - jumlah_uang;
				nasabah[1].saldo = nasabah[1].saldo + jumlah_uang;
			}

		}
		else if (nama == nasabah[1].user)
		{
			if (nasabah[1].saldo < jumlah_uang)
			{
				cout << "\nSaldo Anda Tidak Cukup !\n";
			}
			else
			{
				nasabah[1].saldo = nasabah[1].saldo - jumlah_uang;
				nasabah[0].saldo = nasabah[0].saldo + jumlah_uang;
			}
		}

		cout << "\n========================================\n";
		cout << "Apakah Anda Ingin Transfer Lagi ? ";
		cout << "\n1. Ya";
		cout << "\n2. Tidak";
		cout << "\n\nKetikkan Pilihan = "; cin >> pilihan_ulang;
		cout << "========================================\n";
	}
	while (pilihan_ulang == 1);
}