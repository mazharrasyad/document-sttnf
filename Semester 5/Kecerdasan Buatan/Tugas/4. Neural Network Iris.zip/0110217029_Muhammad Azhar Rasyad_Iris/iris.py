# Sumber : https://github.com/EdoVaira/Iris-Neural-Network

import tensorflow as tf
import pandas as pd
import numpy as np

seed = 1234
np.random.seed(seed)
tf.set_random_seed(seed)

dataset = pd.read_csv('data.csv')
dataset = pd.get_dummies(dataset, columns=['Species'])
values = list(dataset.columns.values)

y = dataset[values[-3:]]
y = np.array(y, dtype='float32')
X = dataset[values[1:-3]]
X = np.array(X, dtype='float32')

indices = np.random.choice(len(X), len(X), replace=False)
X_values = X[indices]
y_values = y[indices]

test_size = 80
X_test = X_values[-test_size:]
X_train = X_values[:-test_size]
y_test = y_values[-test_size:]
y_train = y_values[:-test_size]

sess = tf.Session()

interval = 20
epoch = 80

X_data = tf.placeholder(shape=[None, 4], dtype=tf.float32)
y_target = tf.placeholder(shape=[None, 3], dtype=tf.float32)

hidden_layer_nodes = 8

w1 = tf.Variable(tf.random_normal(shape=[4,hidden_layer_nodes]))
b1 = tf.Variable(tf.random_normal(shape=[hidden_layer_nodes]))
w2 = tf.Variable(tf.random_normal(shape=[hidden_layer_nodes,3]))
b2 = tf.Variable(tf.random_normal(shape=[3]))

hidden_output = tf.nn.relu(tf.add(tf.matmul(X_data, w1), b1))
final_output = tf.nn.softmax(tf.add(tf.matmul(hidden_output, w2), b2))

loss = tf.reduce_mean(-tf.reduce_sum(y_target * tf.log(final_output), axis=0))

optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.008).minimize(loss)

init = tf.global_variables_initializer()
sess.run(init)

print('Pelatihan model...')
for i in range(1, (epoch + 1)):
    sess.run(optimizer, feed_dict={X_data: X_train, y_target: y_train})
    if i % interval == 0:
        print('Epoch', i, '|', 'Loss:', sess.run(loss, feed_dict={X_data: X_train, y_target: y_train}))

print()
for i in range(len(X_test)):
    print('Actual:', y_test[i], 'Predicted:', np.rint(sess.run(final_output, feed_dict={X_data: [X_test[i]]})))