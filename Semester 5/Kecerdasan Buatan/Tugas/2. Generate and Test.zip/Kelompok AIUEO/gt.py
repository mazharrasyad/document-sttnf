from os import system, name 
from time import sleep 
  
def clear(): 
    if name == 'nt': 
        _ = system('cls') 
    else: 
        _ = system('clear') 

def concatenate_list_data(list):
    result= ''
    for element in list:
        result += str(element)
        result += '  '
    return result

def gt(graf, mulai, tujuan) : 
    clear()  
    print("Heuristic Search : Generate and Test\n")
    stack = [[mulai]]
    nilai = [[0]]
    temp = {}
    loop = 1
    print("Rute Awal :", mulai)
    print("Rute Akhir :", tujuan)    
    input()
    print("Graf")
    for i, j in graf.items() :
        print(i, j)
    input()
    while stack : 
        clear()
        print("====================================================")     
        print("Loop ke", loop)      
        print()
        print("Stack Rute :", stack)
        print("Stack Panjang :", nilai)
        input()
        loop += 1     
        panjang_tumpukan = len(stack)-1   

        if stack[0][0] == mulai and stack[-1][-1] == tujuan :            
            temp[concatenate_list_data(stack[panjang_tumpukan])] = str(sum(nilai[panjang_tumpukan]))                        
        
        jalur = stack.pop(panjang_tumpukan)
        jarak = nilai.pop(panjang_tumpukan)
        print("Pilih Rute :", jalur, "dengan Panjang :", sum(jarak))
        state = jalur[-1]
        print("State :", state)
        input()

        print("Cabang State", state,":", sorted(graf.get(state, {}), reverse = True))
        input()
        for cabang in sorted(graf.get(state, {}), reverse = True) :            
            print("====================================================")     
            print("Cabang :", cabang, "dengan Panjang :", graf[state][cabang])            
            input()
            jalur_baru = list(jalur)
            jarak_baru = list(jarak)
            print("Rute Lama :", jalur_baru, "dengan Panjang Lama :", sum(jarak_baru))
            jalur_baru.append(cabang)
            jarak_baru.append(graf[state][cabang])
            print("Rute Baru :", jalur_baru, "dengan Panjang Baru :", sum(jarak_baru))            
            input()
            stack.append(jalur_baru)
            nilai.append(jarak_baru)
            print("Stack Rute Baru :", stack)
            print("Stack Panjang Baru :", nilai)
            input()
        input()
    print()
    clear()
    print("Heuristic Search : Generate and Test\n")
    print("No\tRute\t\tPanjang\t\tRute dipilih\tPanjang dipilih")
    no = 1
    rute_pilih = list(temp)[0]
    panjang_pilih = list(temp.values())[0]
    for rute, panjang in temp.items() :
        print(no, end = '\t')        
        print(rute, end = '\t')
        print(panjang, end = '\t\t')
        if panjang <= panjang_pilih :
            rute_pilih = rute
            panjang_pilih = panjang
        print(rute_pilih, end = '\t')    
        print(panjang_pilih, end = '\t')
        input()
        no += 1
    input("Selesai")
        
graf = {
    'A' : {'B' : 6, 'D' : 4, 'E' : 4},
    'B' : {'C' : 5, 'D' : 5},
    'C' : {},
    'D' : {'C' : 6},
    'E' : {'B' : 2, 'D' : 3},
}

print(gt(graf, 'A', 'C'))