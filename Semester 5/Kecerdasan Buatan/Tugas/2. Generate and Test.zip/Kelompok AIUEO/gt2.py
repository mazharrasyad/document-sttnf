def concatenate_list_data(list):
    result= ''
    for element in list:
        result += str(element)
        result += '  '
    return result

def gt(graf, mulai, tujuan) : 
    stack = [[mulai]]
    nilai = [[0]]
    temp = {}
    loop = 1
    while stack :     
        panjang_tumpukan = len(stack)-1

        if stack[0][0] == mulai and stack[-1][-1] == tujuan :            
            temp[concatenate_list_data(stack[panjang_tumpukan])] = str(sum(nilai[panjang_tumpukan]))                        
        
        jalur = stack.pop(panjang_tumpukan)
        jarak = nilai.pop(panjang_tumpukan)
        state = jalur[-1]

        for cabang in sorted(graf.get(state, {}), reverse = True) :            
            jalur_baru = list(jalur)
            jarak_baru = list(jarak)
            jalur_baru.append(cabang)
            jarak_baru.append(graf[state][cabang])
            stack.append(jalur_baru)
            nilai.append(jarak_baru)        

    print("Heuristic Search : Generate and Test\n")
    print("No\tKemungkinan Rute\tPanjang Rute\tPilih Rute\tPilih Panjang")
    no = 1
    rute_pilih = list(temp)[0]
    panjang_pilih = list(temp.values())[0]
    for rute, panjang in temp.items() :
        print(no, end = '\t')        
        print(rute, end = '\t\t')
        print(panjang, end = '\t\t')
        if panjang <= panjang_pilih :
            rute_pilih = rute
            panjang_pilih = panjang
        print(rute_pilih, end = '\t')    
        print(panjang_pilih, end = '\t')
        input()
        no += 1
    input("Selesai")

graf = {
    'A' : {'B' : 1, 'C' : 2},
    'B' : {'C' : 3},
    'C' : {'D' : 4},
    'D' : {},
}

print(gt(graf, 'A', 'D'))