package id.my.note.restclientdemo;

public class Mahasiswa {
    String name,
            nim;
    int id;

    public String getNama() {
        return name;
    }

    public void setNama(String nama) {
        this.name = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Mahasiswa{" +
                "nama='" + name + '\'' +
                '}';
    }
}
