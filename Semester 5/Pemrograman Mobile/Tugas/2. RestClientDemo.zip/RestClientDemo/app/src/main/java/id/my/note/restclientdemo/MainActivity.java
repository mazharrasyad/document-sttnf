package id.my.note.restclientdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    MahasiswaService service;
    ListView mylist;
    ArrayAdapter<Mahasiswa> adapter;
    List<Mahasiswa> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data = new ArrayList<Mahasiswa>();

        mylist = findViewById(R.id.myList);
        adapter = new ArrayAdapter<Mahasiswa>(this,
                android.R.layout.simple_list_item_1,data);


        mylist.setAdapter(adapter);

        service = APIClient.getClient().create(MahasiswaService.class);
        Call<List<Mahasiswa>> call = service.getMahasiswa();
        ((retrofit2.Call) call).enqueue(new Callback() {
            @Override
            public void onResponse(retrofit2.Call call, Response response) {
                Log.i("MYLOG","DATA DARI SERVER:"+response.body());
                data = (List<Mahasiswa>) response.body();
                adapter.addAll(data);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(retrofit2.Call call, Throwable t) {
                Log.e("MYLOG","GAGAL Ambil data");
            }
        });


    }
}
