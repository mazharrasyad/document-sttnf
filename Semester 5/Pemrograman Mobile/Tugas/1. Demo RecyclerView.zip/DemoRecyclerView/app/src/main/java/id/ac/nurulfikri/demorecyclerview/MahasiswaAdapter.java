package id.ac.nurulfikri.demorecyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MahasiswaAdapter extends
        RecyclerView.Adapter<MahasiswaAdapter.MahasiswaViewHolder> {

    private ArrayList<Mahasiswa> data;

    public MahasiswaAdapter(ArrayList<Mahasiswa> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public MahasiswaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.card_item,parent,false);
        return new MahasiswaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MahasiswaViewHolder holder, int position) {
        holder.txt_atas.setText(data.get(position).getNama());
        holder.txt_bawah.setText(data.get(position).getNim());
//        holder.foto.setImageDrawable();
    }

    @Override
    public int getItemCount() {
        return data!=null?data.size() : 0;
    }

    public class MahasiswaViewHolder extends RecyclerView.ViewHolder{
        private ImageView foto;
        private TextView txt_atas,txt_bawah;
        public MahasiswaViewHolder(@NonNull View itemView) {
            super(itemView);
            foto = itemView.findViewById(R.id.gambar);
            txt_atas = itemView.findViewById(R.id.text_atas);
            txt_bawah = itemView.findViewById(R.id.text_bawah);
        }
    }
}
