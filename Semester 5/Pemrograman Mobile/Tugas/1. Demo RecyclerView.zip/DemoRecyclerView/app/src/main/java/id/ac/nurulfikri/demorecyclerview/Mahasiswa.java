package id.ac.nurulfikri.demorecyclerview;

public class Mahasiswa {
    private String foto,nama,nim;


    public Mahasiswa() {
    }

    public Mahasiswa(String foto, String nama, String nim) {
        this.foto = foto;
        this.nama = nama;
        this.nim = nim;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }
}
