package id.ac.nurulfikri.demorecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Mahasiswa> data = new ArrayList<>();
        data.add(new Mahasiswa("","Adi","12345"));
        data.add(new Mahasiswa("","Ade","12346"));
        data.add(new Mahasiswa("","Adu","12347"));
        data.add(new Mahasiswa("","Ada","12348"));
        data.add(new Mahasiswa("","Ado","12349"));

        recyclerView = findViewById(R.id.list_mahasiswa);
        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        MahasiswaAdapter adapter = new MahasiswaAdapter(data);
        recyclerView.setAdapter(adapter);

    }
}
