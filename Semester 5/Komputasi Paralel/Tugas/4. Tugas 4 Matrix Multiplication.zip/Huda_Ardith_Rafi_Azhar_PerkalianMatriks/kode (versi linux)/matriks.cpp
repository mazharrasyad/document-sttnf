#include <iostream>
#include <iomanip>
#include <fstream>
#include <time.h>

using namespace std;

float matriks1[10000][10000] = {};
float matriks2[10000][10000] = {};
float matriks3[10000][10000] = {};

int main(){
    // Deklarasi Variable
    clock_t mulai = clock();
    ofstream file;    
    int baris1, kolom1, baris2, kolom2;

    cout << "===== Perkalian Matriks ====" << endl;

    // Input Baris dan Kolom
    cout << "Masukkan Matriks 1" << endl;
    cout << "Baris : ";
    cin >> baris1;
    cout << "Kolom : ";
    cin >> kolom1;

    cout << endl << "Masukkan Matriks 2" << endl;
    cout << "Baris : ";
    cin >> baris2;
    cout << "Kolom : ";
    cin >> kolom2;

    // Deklarasi Variable
    matriks1[baris1][kolom1];
    matriks2[baris2][kolom2];
    matriks3[baris1][kolom2];
    int i, j, k;
    float jumlah;
    srand(time(0));
    
    // Verifikasi
    if(kolom1 == baris2){
        // Memasukkan Data Matriks 1
        file.open ("matriks1.txt");
        for(i = 0; i < baris1; i++){
            for(j = 0; j < kolom1; j++){                     
                matriks1[i][j] = (float(rand()) / float(RAND_MAX) * 10);                                   
                file << setprecision(3) << matriks1[i][j] << "\t";
            }
            file << endl;
        }
        file.close();

        // Memasukkan Data Matriks 2
        file.open ("matriks2.txt");
        for(i = 0; i < baris2; i++){
            for(j = 0; j < kolom2; j++){                     
                matriks2[i][j] = (float(rand()) / float(RAND_MAX) * 10);                                       
                file << setprecision(3) << matriks2[i][j] << "\t";
            }
            file << endl;
        }
        file.close();
        
        // Menghitung Perkalian Matriks 1 dan Matriks 2 untuk Matriks 3
        file.open ("matriks3.txt");
        for(i = 0; i < baris1; i++){
            for(j = 0; j < kolom2; j++){  
                for(k = 0; k < baris2; k++){                                              
                    jumlah = float(jumlah + (matriks1[i][k] * matriks2[k][j]));
                }        
                matriks3[i][j] = jumlah;      
                file << setprecision(3) << matriks3[i][j] << "\t";
                jumlah = 0;
            }            
            file << endl;                        
        }
        file.close();
    }   
    else{
        cout << endl << "Matriks 1 dan Matriks 2 Tidak dapat diKalikan" << endl;
    }

    // Menghitung Total Waktu Program
    cout << "\nWaktu Eksekusi Program : " << double(clock() - mulai) / CLOCKS_PER_SEC << " Detik" << endl;
}