<!-- Footer -->
<footer class="footer">
    <div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-12">
        <div class="copyright text-center text-xl-left text-muted">
        Copyright &copy; 2019 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">Link & Match Kelompok 3</a>
        </div>
    </div>
    </div>
</footer>
</div>