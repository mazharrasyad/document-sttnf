<?php $__env->startSection('subtitle'); ?>
    Anggota Proyek
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="main-content">
    <!-- Page content -->
    <div class="container-fluid mt-4">
      <div class="row">
        
        <div class="col-xl-12">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-12">
                  <h3 class="mb-0">ANGGOTA TIM PROYEK - UBAH DATA</h3>
                </div>                
              </div>
            </div>
            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(route('membertim.update', $membertim->id)); ?>" method="post" enctype="multipart/form-data">                
                <?php echo $__env->make('layouts.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PATCH">

                
                <div class="pl-lg-4">                    
                <div class="row">
                  <div class="col-lg-3">
                    <div class="form-group">
                      <label class="form-control-label mr-4" for="input-username">Tim</label>                                                                    
                    </div>                      
                  </div>
                  <div class="col-lg-9">
                  <div class="form-group">
                      <select name="tim_id" id="tim_id" class="btn btn-secondary dropdown-toggle" type="button">     
                        <option value="" disabled selected>Pilih Tim</option>                           
                        <?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($tim->id == $membertim->tim_id): ?>
                              <option value="<?php echo e($membertim->tim_id); ?>" selected><?php echo e($membertim->tim->nama); ?></option>
                          <?php else: ?>
                              <option value="<?php echo e($tim->id); ?>"><?php echo e($tim->nama); ?></option>
                          <?php endif; ?>                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                      </select>
                  </div>
                  </div>
                </div>
                </div>

                
                <div class="pl-lg-4">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label" for="mahasiswa_id">Mahasiswa</label>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="form-group">
                          <select name="mahasiswa_id" id="mahasiswa_id" class="btn btn-secondary dropdown-toggle" type="button">     
                              <option value="" disabled selected>Pilih Mahasiswa</option>                           
                              <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($mahasiswa->id == $membertim->mahasiswa_id): ?>
                                    <option value="<?php echo e($membertim->mahasiswa_id); ?>" selected><?php echo e($membertim->mahasiswa->nama); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($mahasiswa->id); ?>"><?php echo e($mahasiswa->nama); ?></option>
                                <?php endif; ?>                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                          </select>
                        </div>
                    </div>
                </div>
                </div>

                
                <div class="pl-lg-4">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label" for="peran">Peran</label>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="form-group">
                            <select name="peran_id" id="peran_id" class="btn btn-secondary dropdown-toggle" type="button">     
                                <option value="" disabled selected>Pilih Peran</option>                           
                                <?php $__currentLoopData = $perans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($peran->id == $membertim->peran_id): ?>
                                        <option value="<?php echo e($membertim->peran_id); ?>" selected><?php echo e($membertim->peran->nama); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($peran->id); ?>"><?php echo e($peran->nama); ?></option>
                                    <?php endif; ?>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                            </select>
                        </div>
                    </div>
                </div>
                </div>
                
                               
                <div class="pl-lg-4">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label" for="tanggung_jawab">Tanggung Jawab</label>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="form-group">
                          <textarea type="text" name="tanggung_jawab" id="tanggung_jawab" class="form-control form-control-alternative text-dark"><?php echo e($membertim->tanggung_jawab); ?></textarea>                                                          
                        </div>
                    </div>
                </div>
                </div>

                
                <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-12">
                            <a href="<?php echo e(url('/membertim')); ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">Ubah</button>
                        </div>
                    </div>
                </div>

              </form>      
            </div>
          </div>
        </div>
      </div>
    <?php echo $__env->make('layouts.copyright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>