<?php $__env->startSection('subtitle'); ?>
    Proyek
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="main-content">
    <!-- Page content -->
    <div class="container-fluid mt-4">
      <div class="row">
        
        <div class="col-xl-12">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-12">
                  <h3 class="mb-0">PROYEK - UBAH DATA</h3>
                </div>                
              </div>
            </div>
            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(route('project.update', $project->id)); ?>" method="post" enctype="multipart/form-data">                
                            
                    <?php echo $__env->make('layouts.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="PATCH">

                    
                    <div class="pl-lg-4">                                              
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="nama">Nama</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <input type="text" name="nama" id="nama" class="form-control form-control-alternative text-dark" placeholder="Contoh : Pengelolaan Proyek" value="<?php echo e($project->nama); ?>">                                                             
                            </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">                                              
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="deskripsi">Deskripsi</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <textarea type="text" name="deskripsi" id="deskripsi" class="form-control form-control-alternative text-dark" placeholder='Contoh : Product Owner dapat membuat proyek untuk dikerjakan mahasiswa'><?php echo e($project->deskripsi); ?></textarea>                                                          
                            </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="tanggal_mulai">Tanggal Mulai</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                                    </div>
                                    <input value="<?php echo e($project->tanggal_mulai); ?>" name="tanggal_mulai" id="tanggal_mulai" class="form-control datepicker text-dark" placeholder="Pilih Tanggal Mulai" type="date">
                                </div>
                                <label class="form-control-label">Contoh : 01/01/2019 (Bulan/Tanggal/Tahun)</label>
                            </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="tanggal_akhir">Tanggal Akhir</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-calendar-grid-58"></i></span>
                                    </div>
                                    <input value="<?php echo e($project->tanggal_akhir); ?>" name="tanggal_akhir" id="tanggal_akhir" class="form-control datepicker text-dark" placeholder="Pilih Tanggal Akhir Proyek" type="date">
                                </div>
                                <label class="form-control-label">Contoh : 12/31/2019 (Bulan/Tanggal/Tahun)</label>
                            </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">                                              
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="jumlah_sprint">Jumlah Sprint</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <input type="number" name="jumlah_sprint" id="jumlah_sprint" class="form-control form-control-alternative text-dark" placeholder="Contoh : 12" value="<?php echo e($project->jumlah_sprint); ?>">                                                             
                            </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">                                              
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label class="form-control-label" for="budget">Budget</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <input type="text" name="budget" id="budget" class="form-control form-control-alternative text-dark" placeholder="Contoh : Rp5.000.000" value="<?php echo e($project->budget); ?>">                                                             
                            </div>
                        </div>
                    </div>
                    </div>
                    
                    
                    

                    
                    

                    
                    <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label mr-4" for="input-username">Semester</label>                                                                    
                        </div>                      
                        </div>
                        <div class="col-lg-9">
                        <div class="form-group">
                            <select name="semester_id" id="semester_id" class="btn btn-secondary dropdown-toggle" type="button">     
                                <option value="" disabled selected>Pilih Semester</option>                           
                                <?php $__currentLoopData = $semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($semester->id == $project->semester_id): ?>
                                        <option value="<?php echo e($project->semester_id); ?>" selected><?php echo e($project->semester->nama); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($semester->id); ?>"><?php echo e($semester->nama); ?></option>
                                    <?php endif; ?>                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                            </select>
                        </div>
                        </div>
                    </div>
                    </div>

                    
                    <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label mr-4" for="scrummaster">Scrum Master</label>                                                                    
                        </div>                      
                        </div>
                        <div class="col-lg-9">
                        <div class="form-group">
                            <select name="scrummaster_id" id="scrummaster_id" class="btn btn-secondary dropdown-toggle" type="button">     
                                <option value="" disabled selected>Pilih Scrum Master</option>                           
                                <?php $__currentLoopData = $scrummasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrummaster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($scrummaster->id == $project->scrummaster_id): ?>
                                        <option value="<?php echo e($project->scrummaster_id); ?>" selected><?php echo e($project->scrummaster->nama); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($scrummaster->id); ?>"><?php echo e($scrummaster->nama); ?></option>
                                    <?php endif; ?>                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                            </select>
                        </div>
                        </div>
                    </div>
                    </div>
                    
                    
                    

                       
                    
                    
                    
                    <div class="pl-lg-4">
                    <div class="row">
                        <div class="col-lg-12">
                            <a href="<?php echo e(url('/project')); ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">Kirim</button>
                        </div>
                    </div>
                    </div>

              </form>      
            </div>
          </div>
        </div>
      </div>
    <?php echo $__env->make('layouts.copyright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>