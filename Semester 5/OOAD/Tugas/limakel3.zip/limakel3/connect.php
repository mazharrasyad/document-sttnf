<?php

$conn = mysqli_connect("localhost", "root", "", "limakel3");

/*
if($conn){
	echo "Berhasil";
}else{
	echo "Gagal";
}
*/

?>
