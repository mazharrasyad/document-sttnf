# PRAKTIKUM 02

Latihan menggunakan Gii (Code Generator) pada Yii Framework

## Tahapan Memulai

Clone project ini pada folder web-lanjut-sttnf-20182-ti1

```
git clone -b master https://gitlab.com/web-lanjut-sttnf-20182-ti1/praktikum02.git
```

Setelah clone selesai, copy folder **vendor** pada project *mybasic* ke folder *praktikum02*

### Buat Branch

Masuk ke folder **praktikum02**, lalu buat branch baru dengan format *[NIM_NAMA]*

```
cd praktikum02
```

Contoh buat branch:

```
git checkout -b 0110217034_fikri
```
