<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Pegawai */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Pegawais', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="pegawai-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <div class="row">
      <div class="cd-md-7">
        <?= DetailView::widget([
            'model' => $model,
            'attributes' => [
                'id',
                'nip',
                'nama',
                'gender',
                'tempat_lahir',
                'tanggal_lahir',
                // 'idgol',
                'gol.golongan',
                // 'idsubbagian',
                'subbagian.nama',
                // 'idagama',
                'agama.nama',
                'alamat:ntext',
                'hp',
                'email:email',
                'foto',
                'cv',
            ],
        ]) ?>
      </div>
      <div class="col-md-5">
        <img src="<?= Yii::$app->request->baseUrl; ?>/foto/<?= $model->foto; ?>" widht="60%">
        <br><br>
        <a href="<?= Yii::$app->request->baseUrl; ?>/cv/<?= $model->cv; ?>">
          unduk CV
        </a>
      </div>
    </div>
</div>
