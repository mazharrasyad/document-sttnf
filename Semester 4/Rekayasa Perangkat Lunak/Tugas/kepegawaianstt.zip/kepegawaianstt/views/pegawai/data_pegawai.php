<!DOCTYPE html>
<html>
<head>
    <title>Data Pegawai</title>
    <style>
        .page
        {
            padding:2cm;
        }
        table
        {
            border-spacing:0;
            border-collapse: collapse;
            width:100%;
        }
        table td, table th
        {
            border: 1px solid #ccc;
        }

		table th
        {
            background-color:red;
        }
    </style>
</head>
<body>
    <?php
    $ar_judul = ['No','NIP','Nama','Jenis Kelamin','Agama',
                'Departemen','Golongan','Pangkat','Alamat','HP',
                'Email'];
    ?>
    <div class="page">
        <h1>Data Pegawai</h1>
        <table>
        <tr>
            <?php
            foreach($ar_judul as $jdl){
            ?>
                <th><?= $jdl; ?></th>
            <?php } ?>
        </tr>
        <?php
        $no = 1;
        foreach($dataProvider->getModels() as $peg){
        ?>
        <tr>
                <td><?= $no++ ?></td>
                <td><?= $peg->nip ?></td>
                <td><?= $peg->nama ?></td>
                <td><?= $peg->gender ?></td>
                <td><?= $peg->agama->nama ?></td>
                <td><?= $peg->subbagian->nama ?></td>
                <td><?= $peg->gol->golongan ?></td>
                <td><?= $peg->gol->pangkat ?></td>
                <td><?= $peg->alamat ?></td>
                <td><?= $peg->hp ?></td>
                <td><?= $peg->email ?></td>
        </tr>
        <?php
        }
        ?>
        </table>
    </div>
</body>
</html>
