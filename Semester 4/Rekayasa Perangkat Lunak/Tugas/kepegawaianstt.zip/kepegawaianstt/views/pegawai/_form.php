<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
// Tambahan
use kartik\date\DatePicker;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Agama;
use app\models\Gol;
use app\models\SubBagian;

/* @var $this yii\web\View */
/* @var $model app\models\Pegawai */
/* @var $form yii\widgets\ActiveForm */

?>

<div class="pegawai-form">

    <?php
        $ar_agama = ArrayHelper::map(Agama::find()->asArray()->all(),'id','nama');
        $ar_subbagian = ArrayHelper::map(SubBagian::find()->asArray()->all(),'id','nama');
        $ar_gol = ArrayHelper::map(Gol::find()->asArray()->all(),'id','golongan');
        $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]);
    ?>

    <?= $form->field($model, 'nip')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'gender')->dropDownList([ 'Pria' => 'Pria', 'Wanita' => 'Wanita', ], ['prompt' => '']) ?>

    <?= $form->field($model, 'tempat_lahir')->textInput(['maxlength' => true]) ?>

    <!-- < ?= $form->field($model, 'tanggal_lahir')->textInput() ?> -->
    <?= $form->field($model, 'tanggal_lahir')
        ->widget(DatePicker::classname(), [
            'language' => 'id',
            'options' => ['placeholder' => 'Pilih Tanggal...'],
            'pluginOptions' => [
                'format' => 'yyyy-mm-dd',
                'todayHighlight' => true,
                'autoclose' => true,
            ]
        ]) ?>

    <!-- < ?= $form->field($model, 'idgol')->textInput() ?> -->
    <?= $form->field($model, 'idgol')
        ->widget(Select2::classname(), [
            'data' => $ar_gol,
            'language' => 'id',
            'options' => ['placeholder' => 'Pilih Golongan...'],
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>

    <?= $form->field($model, 'idsubbagian')->textInput()
    ->widget(Select2::classname(), [
        'data' => $ar_subbagian,
        'language' => 'id',
        'options' => ['placeholder' => 'Pilih sub bagian...'],
        'pluginOptions' => [
            'allowClear' => true,
        ],
    ]) ?>
    <!-- < ?= $form->field($model, 'idagama')->textInput() ?> -->
    <?= $form->field($model, 'idagama')
        ->widget(Select2::classname(), [
            'data' => $ar_agama,
            'language' => 'id',
            'options' => ['placeholder' => 'Pilih Agama...'],
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>

    <?= $form->field($model, 'alamat')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'hp')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fotoFile')->fileInput() ?>

    <?= $form->field($model, 'cvFile')->fileInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Simpan', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
