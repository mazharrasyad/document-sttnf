<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pegawai".
 *
 * @property int $id
 * @property string $nip
 * @property string $nama
 * @property string $gender
 * @property string $tempat_lahir
 * @property string $tanggal_lahir
 * @property int $idgol
 * @property int $idsubbagian
 * @property int $idagama
 * @property string $alamat
 * @property string $hp
 * @property string $email
 * @property string $foto
 * @property string $cv
 *
 * @property Gaji[] $gajis
 * @property Agama $agama
 * @property Gol $gol
 * @property Subbbagian $subbagian
 * @property Pelatihan[] $pelatihans
 */
class Pegawai extends \yii\db\ActiveRecord
{
  // Buat variabel baru u/ simpan fisik file
  public $fotoFile;
  public $cvFile;

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pegawai';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nip', 'nama', 'gender', 'tempat_lahir', 'tanggal_lahir', 'idgol', 'idsubbagian', 'idagama', 'alamat', 'hp'], 'required'],
            [['gender', 'alamat'], 'string'],
            [['tanggal_lahir'], 'safe'],
            [['idgol', 'idsubbagian', 'idagama'], 'integer'],
            [['nip'], 'string', 'max' => 18],
            [['nama', 'tempat_lahir', 'email', 'foto', 'cv'], 'string', 'max' => 45],
            [['hp'], 'string', 'max' => 15],
            [['nip'], 'unique'],
            [['idagama'], 'exist', 'skipOnError' => true, 'targetClass' => Agama::className(), 'targetAttribute' => ['idagama' => 'id']],
            [['idgol'], 'exist', 'skipOnError' => true, 'targetClass' => Gol::className(), 'targetAttribute' => ['idgol' => 'id']],
            [['idsubbagian'], 'exist', 'skipOnError' => true, 'targetClass' => SubBagian::className(), 'targetAttribute' => ['idsubbagian' => 'id']],
            //rule tambahan
            [['email'], 'email'],
            [['fotoFile'], 'file',
            'skipOnEmpty' => true,
            'extensions' => 'png, jpg',
            'minSize' => 10240, //minimal 10 kb = 10240 Byte
            'maxSize' => 512000, //Maksimal 500kb = 512000 Byte
            ],
            [['cvFile'], 'file',
            'skipOnEmpty' => true,
            'extensions' => 'pdf, docx, doc, odt',
            'minSize' => 10240, //minimal 10 kb = 10240 Byte
            'maxSize' => 512000, //Maksimal 500kb = 512000 Byte
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nip' => 'Nip',
            'nama' => 'Nama',
            'gender' => 'Jenis Kelamin',
            'tempat_lahir' => 'Tempat Lahir',
            'tanggal_lahir' => 'Tanggal Lahir',
            'idgol' => 'Golongan',
            'idsubbagian' => 'Sub bagian',
            'idagama' => 'Agama',
            'alamat' => 'Alamat',
            'hp' => 'Hp',
            'email' => 'Email',
            'foto' => 'Foto',
            'cv' => 'Cv',
            //========================= Tambah attribute label ==================
            'fotoFile' => 'File Foto',
            'cvFile' => 'File Cv',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGajis()
    {
        return $this->hasMany(Gaji::className(), ['idpegawai' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAgama()
    {
        return $this->hasOne(Agama::className(), ['id' => 'idagama']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGol()
    {
        return $this->hasOne(Gol::className(), ['id' => 'idgol']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSubbagian()
    {
        return $this->hasOne(SubBagian::className(), ['id' => 'idsubbagian']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPelatihans()
    {
        return $this->hasMany(Pelatihan::className(), ['idpegawai' => 'id']);
    }
}
