<?php

namespace app\controllers;

use Yii;
use app\models\Pegawai;
use app\models\PegawaiSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
//--------tambahan------------
use yii\web\UploadedFile;

/**
 * PegawaiController implements the CRUD actions for Pegawai model.
 */
class PegawaiController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Pegawai models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PegawaiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Pegawai model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Pegawai model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Pegawai();
        /*
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }
        */

        //------------proses upload file---------------
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            //upload dokumennya
            $model->fotoFile = UploadedFile::getInstance($model, 'fotoFile');

            $model->cvFile = UploadedFile::getInstance($model, 'cvFile');
            //-------logika 4 kemungkinan------
            if($model->validate() && !empty($model->fotoFile) && !empty($model->cvFile)){
                //simpan nama filenya
                //$nama1 = $model->fotoFle->baseName;
                $nama1 = 'foto-'.$model->nip.'.'.$model->fotoFile->extension;
                $model->foto = $nama1;
                $nama2 = 'cv-'.$model->nip.'.'.$model->cvFile->extension;;
                $model->cv = $nama2;
                //simpan semua data
                $model->save();
                //fisik file simpan ke sebuah folder
                $model->fotoFile->saveAs('foto/'.$nama1);
                $model->cvFile->saveAs('cv/'.$nama2);
            }
            else if($model->validate() && !empty($model->fotoFile)){
                //simpan nama filenya
                //$nama1 = $model->fotoFle->baseName;
                $nama1 = 'foto-'.$model->nip.'.'.$model->fotoFile->extension;
                $model->foto = $nama1;
                //simpan semua data
                $model->save();
                //fisik file simpan ke sebuah folder
                $model->fotoFile->saveAs('foto/'.$nama1);
            }
            else if($model->validate() && !empty($model->cvFile)){
                //simpan nama filenya
                $nama2 = 'cv-'.$model->nip.'.'.$model->cvFile->extension;;
                $model->cv = $nama2;
                //simpan semua data
                $model->save();
                //fisik file simpan ke sebuah folder
                $model->cvFile->saveAs('cv/'.$nama2);
            }
            else{
                //simpan semua data kecuali foto dan cv
                $model->save();
            }

            return $this->redirect(['view', 'id' => $model->id]);
        }
        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Pegawai model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Pegawai model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Pegawai model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Pegawai the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Pegawai::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionExportPdf()
    {
        $searchModel = new PegawaiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $html = $this->renderPartial('data_pegawai',['dataProvider'=>$dataProvider]);
        $mpdf=new \mPDF('c','A4-L','','' , 0 , 0 , 0 , 0 , 0 , 0);
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->list_indent_first_level = 0;  // 1 or 0 - whether to indent the first level of a list
        $mpdf->WriteHTML($html);
        $mpdf->Output();
        exit;
    }

    public function actionExportExcel2()
    {
        $searchModel = new PegawaiSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        // Initalize the TBS instance
        $OpenTBS = new \hscstudio\export\OpenTBS; // new instance of TBS
        // Change with Your template kaka
		$template = Yii::getAlias('@hscstudio/export').'/templates/opentbs/data-pegawai.xlsx';
        $OpenTBS->LoadTemplate($template); // Also merge some [onload] automatic fields (depends of the type of document).
        //$OpenTBS->VarRef['modelName']= "Mahasiswa";
        $data = [];
        $no=1;
        foreach($dataProvider->getModels() as $peg){
            $data[] = [
                'no'=>$no++,
                'nip'=>$peg->nip,
                'nama'=>$peg->nama,
                'jk'=>$peg->gender,
                'agama'=>$peg->agama->nama,
                'sb'=>$peg->subbagian->nama,
                'gol'=>$peg->gol->golongan,
                'pang'=>$peg->gol->pangkat,
                'alamat'=>$peg->alamat,
                'hp'=>$peg->hp,
                'email'=>$peg->email,
            ];
        }
        $OpenTBS->MergeBlock('data', $data);
        // Output the result as a file on the server. You can change output file
        $OpenTBS->Show(OPENTBS_DOWNLOAD, 'pegawai.xlsx'); // Also merges all [onshow] automatic fields.
        exit;
    }
}
