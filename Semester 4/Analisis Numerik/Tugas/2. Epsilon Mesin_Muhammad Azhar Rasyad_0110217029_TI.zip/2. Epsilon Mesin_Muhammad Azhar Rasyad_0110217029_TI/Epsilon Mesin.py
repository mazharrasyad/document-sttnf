print("===== Program Mencari Epsilon Mesin =====\n")

eps = 1
eps1 = 1

i = 1
while eps + 1 > 1 :                    
    eps1 = float(eps)
    eps = float(eps) / 2            
    print("Iterasi ke " + str(i) + " : " + str(eps1) + " / 2 = " + str(eps))    
    i += 1    
print("Berhenti Pada eps : " + str(eps))  

eps = 2 * eps
print("\nNilai Epsilon Mesin Python : " + str(eps))