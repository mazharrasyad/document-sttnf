<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "seminar".
 *
 * @property int $id
 * @property string $tanggal
 * @property string $nama
 * @property string $tempat
 * @property string $keterangan
 */
class Seminar extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'seminar';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tanggal'], 'safe'],
            [['nama'], 'string', 'max' => 45],
            [['tempat', 'keterangan'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'tanggal' => 'Tanggal',
            'nama' => 'Nama',
            'tempat' => 'Tempat',
            'keterangan' => 'Keterangan',
        ];
    }
}
