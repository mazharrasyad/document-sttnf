<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use app\models\Prodi;
use yii\helpers\ArrayHelper;
use app\models\RombonganBelajar;

/* @var $this yii\web\View */
/* @var $model app\models\Mahasiswa */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="mahasiswa-form">

    <?php 
        $ar_prodi = ArrayHelper::map(Prodi::find()->asArray()->all(),'id','nama');
        $ar_rombel = ArrayHelper::map(RombonganBelajar::find()->asArray()->all(),'id','kode');
        $form = ActiveForm::begin(); 
    ?>

    <?= $form->field($model, 'nim')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tmp_lahir')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tgl_lahir')
        ->widget(DatePicker::classname(), [
            'language' => 'id',
            'pluginOptions' => [
                'format' => 'yyyy-mm-dd',
                'todayHighlight' => true,
                'autoclose' => true,
            ]
        ]) ?>

    <?= $form->field($model, 'ipk')->textInput() ?>

    <?= $form->field($model, 'prodi_id')
        ->widget(Select2::classname(), [
            'data' => $ar_prodi,
            'language' => 'id',
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>

    <?= $form->field($model, 'rombel_id')
        ->widget(Select2::classname(), [
            'data' => $ar_rombel,
            'language' => 'id',
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
