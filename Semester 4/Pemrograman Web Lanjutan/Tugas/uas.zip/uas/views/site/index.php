<?php
/* @var $this yii\web\View */

$this->title = 'UAS PWL';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>UAS PWL STTNF</h1>

        <p class="lead">Pemrograman Web Lanjutan</p>

        <i>Selamat Mengerjakan!!</i><br>
        <i>Katakan Tidak Pada Mencontek!!</i>
    </div>

    <div class="body-content text-center">
    </div>
</div>
