<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use kartik\select2\Select2;
use app\models\Mahasiswa;
use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $model app\models\SeminarTa */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="seminar-ta-form">

    <?php 
        $ar_mahasiswa = ArrayHelper::map(Mahasiswa::find()->asArray()->all(),'nim','nim');
        $form = ActiveForm::begin(); 
    ?>

    <?= $form->field($model, 'tanggal')
        ->widget(DatePicker::classname(), [
            'language' => 'id',
            'pluginOptions' => [
                'format' => 'yyyy-mm-dd',
                'todayHighlight' => true,
                'autoclose' => true,
            ]
        ]) ?>

    <?= $form->field($model, 'judul')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pembimbing')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tempat')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'mahasiswa_nim')
        ->widget(Select2::classname(), [
            'data' => $ar_mahasiswa,
            'language' => 'id',
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
