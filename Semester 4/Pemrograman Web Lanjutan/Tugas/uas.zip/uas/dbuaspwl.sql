-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 23 Jul 2019 pada 05.20
-- Versi server: 10.3.15-MariaDB
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbuaspwl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('ADMINISTRATOR', '1', 1563849816),
('PETUGAS SEMINAR', '2', 1563849823);

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/*', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/admin/*', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/assignment/*', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/assignment/assign', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/assignment/index', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/admin/assignment/revoke', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/assignment/view', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/default/*', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/default/index', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/*', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/create', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/delete', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/index', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/update', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/menu/view', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/permission/*', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/permission/assign', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/permission/create', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/permission/delete', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/permission/index', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/permission/remove', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/permission/update', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/permission/view', 2, NULL, NULL, NULL, 1563849668, 1563849668),
('/admin/role/*', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/assign', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/create', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/delete', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/index', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/remove', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/update', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/role/view', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/route/*', 2, NULL, NULL, NULL, 1563849670, 1563849670),
('/admin/route/assign', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/route/create', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/route/index', 2, NULL, NULL, NULL, 1563849669, 1563849669),
('/admin/route/refresh', 2, NULL, NULL, NULL, 1563849670, 1563849670),
('/admin/route/remove', 2, NULL, NULL, NULL, 1563849670, 1563849670),
('/admin/rule/*', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/rule/create', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/rule/delete', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/rule/index', 2, NULL, NULL, NULL, 1563849670, 1563849670),
('/admin/rule/update', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/rule/view', 2, NULL, NULL, NULL, 1563849670, 1563849670),
('/admin/user/*', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/activate', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/change-password', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/delete', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/user/index', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/user/login', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/user/logout', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/admin/user/request-password-reset', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/reset-password', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/signup', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/admin/user/view', 2, NULL, NULL, NULL, 1563849671, 1563849671),
('/debug/*', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/default/*', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/default/db-explain', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/debug/default/download-mail', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/default/index', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/debug/default/toolbar', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/default/view', 2, NULL, NULL, NULL, 1563849672, 1563849672),
('/debug/user/*', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/user/reset-identity', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/debug/user/set-identity', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/dosen/*', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/dosen/create', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/dosen/delete', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/dosen/index', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/dosen/update', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/dosen/view', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/gii/*', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/gii/default/*', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/gii/default/action', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/gii/default/diff', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/gii/default/index', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/gii/default/preview', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/gii/default/view', 2, NULL, NULL, NULL, 1563849673, 1563849673),
('/mahasiswa/*', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/mahasiswa/create', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/mahasiswa/delete', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/mahasiswa/index', 2, NULL, NULL, NULL, 1563849674, 1563849674),
('/mahasiswa/update', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/mahasiswa/view', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/*', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/create', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/delete', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/index', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/update', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/peserta-seminar/view', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/prodi/*', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/prodi/create', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/prodi/delete', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/prodi/index', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/prodi/update', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/prodi/view', 2, NULL, NULL, NULL, 1563849675, 1563849675),
('/rombongan-belajar/*', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/rombongan-belajar/create', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/rombongan-belajar/delete', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/rombongan-belajar/index', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/rombongan-belajar/update', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/rombongan-belajar/view', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/seminar-ta/*', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar-ta/create', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar-ta/delete', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar-ta/index', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar-ta/update', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar-ta/view', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar/*', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar/create', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar/delete', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar/index', 2, NULL, NULL, NULL, 1563849676, 1563849676),
('/seminar/update', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/seminar/view', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/site/*', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/site/about', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/site/captcha', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/site/contact', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/site/error', 2, NULL, NULL, NULL, 1563849677, 1563849677),
('/site/index', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/site/login', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/site/logout', 2, NULL, NULL, NULL, 1563849678, 1563849678),
('/user/*', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/admin/*', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/assignments', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/block', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/confirm', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/create', 2, NULL, NULL, NULL, 1563849665, 1563849665),
('/user/admin/delete', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/index', 2, NULL, NULL, NULL, 1563849665, 1563849665),
('/user/admin/info', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/resend-password', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/switch', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/admin/update', 2, NULL, NULL, NULL, 1563849665, 1563849665),
('/user/admin/update-profile', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/profile/*', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/profile/index', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/profile/show', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/recovery/*', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/recovery/request', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/recovery/reset', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/registration/*', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/registration/confirm', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/registration/connect', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/registration/register', 2, NULL, NULL, NULL, 1563849666, 1563849666),
('/user/registration/resend', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/security/*', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/security/auth', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/security/login', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/security/logout', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/*', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/account', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/confirm', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/delete', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/disconnect', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/networks', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('/user/settings/profile', 2, NULL, NULL, NULL, 1563849667, 1563849667),
('ADMINISTRATOR', 1, NULL, NULL, NULL, 1563849776, 1563849776),
('Master Data', 2, NULL, NULL, NULL, 1563849696, 1563849696),
('PETUGAS SEMINAR', 1, NULL, NULL, NULL, 1563849793, 1563849793),
('Seminar Manager', 2, NULL, NULL, NULL, 1563849737, 1563849737);

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('ADMINISTRATOR', 'Master Data'),
('Master Data', '/dosen/*'),
('Master Data', '/mahasiswa/*'),
('Master Data', '/prodi/*'),
('Master Data', '/rombongan-belajar/*'),
('PETUGAS SEMINAR', 'Seminar Manager'),
('Seminar Manager', '/peserta-seminar/*'),
('Seminar Manager', '/seminar-ta/*'),
('Seminar Manager', '/seminar/*');

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosen`
--

CREATE TABLE `dosen` (
  `nidn` varchar(10) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `tmp_lahir` varchar(45) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `jk` char(1) DEFAULT NULL,
  `prodi_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `dosen`
--

INSERT INTO `dosen` (`nidn`, `nama`, `tmp_lahir`, `tgl_lahir`, `jk`, `prodi_id`) VALUES
('0408080411', 'Amalia Rahmah', 'Jakarta', '1987-08-01', 'P', 1),
('0408080412', 'Edo Riansyah', 'Jakarta', '1992-07-23', 'L', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` varchar(15) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `tmp_lahir` varchar(30) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `ipk` double DEFAULT NULL,
  `prodi_id` int(11) NOT NULL,
  `rombel_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `tmp_lahir`, `tgl_lahir`, `ipk`, `prodi_id`, `rombel_id`) VALUES
('0110217029', 'Muhammad Azhar Rasyad', 'Bojonegoro', '1999-03-21', 3, 2, 3),
('0110217030', 'Rasyad', 'Bojonegoro', '2000-02-08', 3, 2, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1563848980),
('m140209_132017_init', 1563848985),
('m140403_174025_create_account_table', 1563848989),
('m140504_113157_update_tables', 1563848996),
('m140504_130429_create_token_table', 1563848999),
('m140506_102106_rbac_init', 1563849328),
('m140830_171933_fix_ip_field', 1563849001),
('m140830_172703_change_account_table_name', 1563849001),
('m141222_110026_update_ip_field', 1563849003),
('m141222_135246_alter_username_length', 1563849006),
('m150614_103145_update_social_account_table', 1563849006),
('m150623_212711_fix_username_notnull', 1563849007),
('m151218_234654_add_timezone_to_profile', 1563849007),
('m160929_103127_add_last_login_at_to_user_table', 1563849008),
('m170907_052038_rbac_add_index_on_auth_assignment_user_id', 1563849328),
('m180523_151638_rbac_updates_indexes_without_prefix', 1563849329);

-- --------------------------------------------------------

--
-- Struktur dari tabel `peserta_seminar`
--

CREATE TABLE `peserta_seminar` (
  `id` int(11) NOT NULL,
  `seminar_ta_id` int(11) NOT NULL,
  `mahasiswa_nim` varchar(15) NOT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `peserta_seminar`
--

INSERT INTO `peserta_seminar` (`id`, `seminar_ta_id`, `mahasiswa_nim`, `status`) VALUES
(1, 1, '0110217029', 'Menunggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `prodi`
--

CREATE TABLE `prodi` (
  `id` int(11) NOT NULL,
  `kode` char(2) DEFAULT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `prodi`
--

INSERT INTO `prodi` (`id`, `kode`, `nama`) VALUES
(1, 'SI', 'Sistem Informasi'),
(2, 'TI', 'Informatika');

-- --------------------------------------------------------

--
-- Struktur dari tabel `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `profile`
--

INSERT INTO `profile` (`user_id`, `name`, `public_email`, `gravatar_email`, `gravatar_id`, `location`, `website`, `bio`, `timezone`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rombongan_belajar`
--

CREATE TABLE `rombongan_belajar` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) DEFAULT NULL,
  `thn_masuk` int(11) DEFAULT NULL,
  `dosen_pa` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `rombongan_belajar`
--

INSERT INTO `rombongan_belajar` (`id`, `kode`, `thn_masuk`, `dosen_pa`) VALUES
(1, 'SI201801', 2018, '0408080411'),
(2, 'SI201802', 2018, '0408080411'),
(3, 'TI20191', 2019, '0408080412');

-- --------------------------------------------------------

--
-- Struktur dari tabel `seminar`
--

CREATE TABLE `seminar` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `tempat` varchar(100) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `seminar`
--

INSERT INTO `seminar` (`id`, `tanggal`, `nama`, `tempat`, `keterangan`) VALUES
(1, '2019-07-29', 'Career Days STTNF', 'Kampus B STTNF', 'Pelatihan Pasca Campus');

-- --------------------------------------------------------

--
-- Struktur dari tabel `seminar_ta`
--

CREATE TABLE `seminar_ta` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `judul` varchar(45) DEFAULT NULL,
  `pembimbing` varchar(45) DEFAULT NULL,
  `tempat` varchar(45) DEFAULT NULL,
  `mahasiswa_nim` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `seminar_ta`
--

INSERT INTO `seminar_ta` (`id`, `tanggal`, `judul`, `pembimbing`, `tempat`, `mahasiswa_nim`) VALUES
(1, '2019-07-31', 'Bimbingan Tugas Akhir', 'Edo Riansyah', 'Kampus B2 STTNF', '0110217029');

-- --------------------------------------------------------

--
-- Struktur dari tabel `social_account`
--

CREATE TABLE `social_account` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `token`
--

CREATE TABLE `token` (
  `user_id` int(11) NOT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  `type` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `token`
--

INSERT INTO `token` (`user_id`, `code`, `created_at`, `type`) VALUES
(1, 'rxkuHLS46h-zz-730z0O_m0FbKAl5hG6', 1563849067, 0),
(2, '_anLexVi1P6J9gx4IjCrH3GJqQZekN4o', 1563849105, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `confirmed_at` int(11) DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blocked_at` int(11) DEFAULT NULL,
  `registration_ip` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  `last_login_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `auth_key`, `confirmed_at`, `unconfirmed_email`, `blocked_at`, `registration_ip`, `created_at`, `updated_at`, `flags`, `last_login_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$Nm1yZRJiYzpXxyfpZalQzeq/kY1K/lF/1tzc9dx/CI8KtdwOP0Nqq', 'Zo572uCwZrv-sm53D5V96yvN4l8ge6Sn', NULL, NULL, NULL, '127.0.0.1', 1563849067, 1563849067, 0, 1563851190),
(2, 'petugas_seminar', 'petugas_seminar@gmail.com', '$2y$10$vNJHpie4ABLkWhi8w/JXMOq0YQXBHd6.pd6jDwjGqrgTEmO2xpro.', 'lwsLlnF4IwxvDvMJyL-wP3lKH1R0HZUA', NULL, NULL, NULL, '127.0.0.1', 1563849105, 1563849105, 0, 1563851749);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`),
  ADD KEY `idx-auth_assignment-user_id` (`user_id`);

--
-- Indeks untuk tabel `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Indeks untuk tabel `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indeks untuk tabel `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indeks untuk tabel `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`nidn`),
  ADD KEY `fk_dosen_prodi_idx` (`prodi_id`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`),
  ADD KEY `fk_mahasiswa_prodi1_idx` (`prodi_id`),
  ADD KEY `fk_mahasiswa_rombongan_belajar1_idx` (`rombel_id`);

--
-- Indeks untuk tabel `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indeks untuk tabel `peserta_seminar`
--
ALTER TABLE `peserta_seminar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_peserta_seminar_seminar_ta1_idx` (`seminar_ta_id`),
  ADD KEY `fk_peserta_seminar_mahasiswa1_idx` (`mahasiswa_nim`);

--
-- Indeks untuk tabel `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_UNIQUE` (`kode`);

--
-- Indeks untuk tabel `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Indeks untuk tabel `rombongan_belajar`
--
ALTER TABLE `rombongan_belajar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_UNIQUE` (`kode`),
  ADD KEY `fk_rombongan_belajar_dosen1_idx` (`dosen_pa`);

--
-- Indeks untuk tabel `seminar`
--
ALTER TABLE `seminar`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `seminar_ta`
--
ALTER TABLE `seminar_ta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_seminar_ta_mahasiswa1_idx` (`mahasiswa_nim`);

--
-- Indeks untuk tabel `social_account`
--
ALTER TABLE `social_account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_unique` (`provider`,`client_id`),
  ADD UNIQUE KEY `account_unique_code` (`code`),
  ADD KEY `fk_user_account` (`user_id`);

--
-- Indeks untuk tabel `token`
--
ALTER TABLE `token`
  ADD UNIQUE KEY `token_unique` (`user_id`,`code`,`type`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_unique_username` (`username`),
  ADD UNIQUE KEY `user_unique_email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `peserta_seminar`
--
ALTER TABLE `peserta_seminar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `rombongan_belajar`
--
ALTER TABLE `rombongan_belajar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `seminar`
--
ALTER TABLE `seminar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `seminar_ta`
--
ALTER TABLE `seminar_ta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `social_account`
--
ALTER TABLE `social_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `dosen`
--
ALTER TABLE `dosen`
  ADD CONSTRAINT `fk_dosen_prodi` FOREIGN KEY (`prodi_id`) REFERENCES `prodi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `fk_mahasiswa_prodi1` FOREIGN KEY (`prodi_id`) REFERENCES `prodi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_mahasiswa_rombongan_belajar1` FOREIGN KEY (`rombel_id`) REFERENCES `rombongan_belajar` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `peserta_seminar`
--
ALTER TABLE `peserta_seminar`
  ADD CONSTRAINT `fk_peserta_seminar_mahasiswa1` FOREIGN KEY (`mahasiswa_nim`) REFERENCES `mahasiswa` (`nim`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `peserta_seminar_ibfk_1` FOREIGN KEY (`seminar_ta_id`) REFERENCES `seminar_ta` (`id`);

--
-- Ketidakleluasaan untuk tabel `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `rombongan_belajar`
--
ALTER TABLE `rombongan_belajar`
  ADD CONSTRAINT `fk_rombongan_belajar_dosen1` FOREIGN KEY (`dosen_pa`) REFERENCES `dosen` (`nidn`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `seminar_ta`
--
ALTER TABLE `seminar_ta`
  ADD CONSTRAINT `fk_seminar_ta_mahasiswa1` FOREIGN KEY (`mahasiswa_nim`) REFERENCES `mahasiswa` (`nim`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `social_account`
--
ALTER TABLE `social_account`
  ADD CONSTRAINT `fk_user_account` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `token`
--
ALTER TABLE `token`
  ADD CONSTRAINT `fk_user_token` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
