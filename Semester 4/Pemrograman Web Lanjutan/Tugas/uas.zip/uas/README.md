# UAS PWL

Project ini digunakan untuk pengumpulan jawaban UAS Pemrograman Web Lanjutan.

## Aturan Ujian

- Batas waktu pengumpulan (push commit) jawaban ujian sampai dengan **23 Juli 2019 11:15**

- Dilarang keras melakukan copy paste pekerjaan teman

## Tahapan Memulai

Clone project ini pada folder web-lanjut-sttnf-20182-ti1

```
git clone -b master https://gitlab.com/web-lanjut-sttnf-20182-ti1/uas.git
```

Setelah clone selesai, copy folder **vendor** pada project *praktikum03* ke folder *uas*

### Buat Branch

Masuk ke folder **uas**, lalu buat branch baru dengan format *[NIM_NAMA]*

```
cd uas
```

Contoh buat branch:

```
git checkout -b 0110217034_fikri
```

### Buat Database & Import

- Buatlah database **dbuaspwl** pada phpMyAdmin
- Lakukan import file [**dbuaspwl.sql**](https://gitlab.com/web-lanjut-sttnf-20182-ti1/uas/blob/master/dbuaspwl.sql) yang ada pada project ini ke database dbuaspwl

Tahapan selesai, silahkan kerjakan soalnya.
