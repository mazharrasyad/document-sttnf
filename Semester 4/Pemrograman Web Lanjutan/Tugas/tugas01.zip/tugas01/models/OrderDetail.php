<?php
namespace app\models;

use yii\db\ActiveRecord;

class OrderDetail extends ActiveRecord
{
	public static function tableName()
	{
		return 'order_details';
	}

	public function rules()
	{
		return [
			[['orders_id','products_id','quantity_order','price_each'],'required'],
			[['orders_id'], 'integer'],
			[['products_id'], 'integer'],
			[['quantity_order'],'integer'],
			[['price_each'],'integer'],
		];
	}

	public static function primaryKey()
	{
		return [
			'orders_id', 'products_id',
		];
	}
}