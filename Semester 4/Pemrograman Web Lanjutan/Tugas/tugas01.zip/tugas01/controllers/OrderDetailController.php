<?php

namespace app\controllers;

use yii\web\Controller;
use Yii;
use app\models\OrderDetail;
use app\models\Product;

class OrderDetailController extends Controller
{
	public function actionCreate()
	{
		$model = new OrderDetail;
		if(Yii::$app->request->post()){
			$request = Yii::$app->request->post('OrderDetail');	
			$product = Product::findOne($request['products_id']);						
			$product->stock = $product->stock - $request['quantity_order'];

			if($product->stock < 0){
				Yii::$app->session->setFlash('error','Stock tidak mencukupi');
			}else{				
				$product->save();

				$model->price_each = $product->price * $request['quantity_order'];			

				$model->load(Yii::$app->request->post());
				if($model->save()){
					Yii::$app->session->setFlash('success','Data berhasil disimpan');
				}else{
					Yii::$app->session->setFlash('error','Data gagal disimpan');
				}				
			}	
			
			return $this->redirect(['index']);
		}else{
			return $this->render('create',[
				'model'=>$model,
			]);
		}
	}

	public function actionIndex()
	{
		$orderdetails = OrderDetail::find()->all();

		return $this->render('index',[
			'orderdetails'=>$orderdetails,
		]);
	}

	public function actionUpdate($orders_id, $products_id)
	{
		$model = OrderDetail::findOne(['orders_id' => $orders_id, 'products_id' => $products_id]);
		if(Yii::$app->request->post()){
			$request = Yii::$app->request->post('OrderDetail');	
			$product = Product::findOne($request['products_id']);						
			$product->stock = $product->stock + $model->quantity_order;
			$product->stock = $product->stock - $request['quantity_order'];

			if($product->stock < 0){
				Yii::$app->session->setFlash('error','Stock tidak mencukupi');
			}else{				
				$product->save();

				$model->price_each = $product->price * $request['quantity_order'];			

				$model->load(Yii::$app->request->post());
				if($model->save()){
					Yii::$app->session->setFlash('success','Data berhasil disimpan');
				}else{
					Yii::$app->session->setFlash('error','Data gagal disimpan');
				}				
			}	
			
			return $this->redirect(['index']);
		}else{
			return $this->render('update',[
				'model'=>$model,
			]);
		}	
	}

	public function actionDelete($orders_id, $products_id)
	{
		$model = OrderDetail::findOne(['orders_id' => $orders_id, 'products_id' => $products_id]);
		$product = Product::findOne($model->products_id);					
		$product->stock = $product->stock + $model->quantity_order;
		$product->save();	
		$model->delete();
		return $this->redirect(['index']);
	}	
}