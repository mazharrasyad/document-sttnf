<?php

namespace app\controllers;

use yii\web\Controller;
use Yii;
use app\models\Customer;

class CustomerController extends Controller
{
	public function actionCreate()
	{
		$model = new Customer;
		if(Yii::$app->request->post()){
			$model->load(Yii::$app->request->post());
			if($model->save()){
				Yii::$app->session->setFlash('success','Data berhasil disimpan');
			}else{
				Yii::$app->session->setFlash('error','Data gagal disimpan');
			}

			return $this->redirect(['index']);
		}else{
			return $this->render('create',[
				'model'=>$model,
			]);
		}
	}

	public function actionIndex()
	{
		$customers = Customer::find()->all();

		return $this->render('index',[
			'customers'=>$customers,
		]);
	}

	public function actionUpdate($id)
	{
		$model = Customer::findOne($id);
		if(Yii::$app->request->post()){
			$model->load(Yii::$app->request->post());
			if($model->save()){
				Yii::$app->session->setFlash('success','Data berhasil diubah');
			}else{
				Yii::$app->session->setFlash('error','Data gagal diubah');
			}

			return $this->redirect(['index']);
		}else{
			return $this->render('update',[
				'model'=>$model,
			]);
		}	
	}

	public function actionDelete($id)
	{
		$model = Customer::findOne($id);
		$model->delete();
		return $this->redirect(['index']);
	}	
}