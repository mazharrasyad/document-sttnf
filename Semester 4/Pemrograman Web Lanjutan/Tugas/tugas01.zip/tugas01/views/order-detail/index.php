<?php
use yii\helpers\Html;
?>
<h1>Daftar Order Detail</h1>
<?php
echo Html::a('Create',['create'],['class'=>'btn btn-primary', 'style'=>'margin-bottom:5px;']);
echo '<table class="table table-bordered table-striped">';
echo '<tr>';
echo '<th>ORDERS ID</th>';
echo '<th>PRODUCTS ID</th>';
echo '<th>QUANTITY ORDER</th>';
echo '<th>PRICE EACH</th>';
echo '<th>ACTION</th>';
echo'</tr>';
foreach ($orderdetails as $orderdetail) {
	echo '<tr>';
	echo '<td>'.$orderdetail->orders_id.'</td>';
	echo '<td>'.$orderdetail->products_id.'</td>';
	echo '<td>'.$orderdetail->quantity_order.'</td>';
	echo '<td>'.$orderdetail->price_each.'</td>';
	echo '<td>';
	echo Html::a('<i class="glyphicon glyphicon-pencil"></i>',['order-detail/update','orders_id'=>$orderdetail->orders_id, 'products_id'=>$orderdetail->products_id]);
	echo Html::a('<i class="glyphicon glyphicon-trash"></i>',['order-detail/delete','orders_id'=>$orderdetail->orders_id, 'products_id'=>$orderdetail->products_id],['onclick'=>'return(confirm("Apakah data mau dihapus?") ? true : false);', 'style'=>'margin-left:10px;']);
	echo '</td>';
	echo '</tr>';
}
echo '</table>';