<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
?>
<h1>Update Product</h1>
<?php $form = ActiveForm::begin(); ?>
	
	<?= $form->field($model,'name') ?>	
	<?= $form->field($model,'description')->textarea() ?>
	<?= $form->field($model,'stock') ?>
	<?= $form->field($model,'price') ?>
	<?= Html::submitButton('Ubah',['class'=>'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>