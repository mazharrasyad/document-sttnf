<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
?>
<h1>Create Product</h1>
<?php $form = ActiveForm::begin(); ?>
	
	<?= $form->field($model,'name') ?>	
	<?= $form->field($model,'description')->textarea() ?>
	<?= $form->field($model,'stock') ?>
	<?= $form->field($model,'price') ?>
	<?= Html::submitButton('Simpan',['class'=>'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>