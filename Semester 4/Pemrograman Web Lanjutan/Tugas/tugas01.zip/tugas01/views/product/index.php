<?php
use yii\helpers\Html;
?>
<h1>Daftar Product</h1>
<?php
echo Html::a('Create',['create'],['class'=>'btn btn-primary', 'style'=>'margin-bottom:5px;']);
echo '<table class="table table-bordered table-striped">';
echo '<tr>';
echo '<th>ID</th>';
echo '<th>NAME</th>';
echo '<th>DESCRIPTION</th>';
echo '<th>STOCK</th>';
echo '<th>PRICE</th>';
echo '<th>ACTION</th>';
echo'</tr>';
foreach ($products as $product) {
	echo '<tr>';
	echo '<td>'.$product->id.'</td>';
	echo '<td>'.$product->name.'</td>';
	echo '<td>'.$product->description.'</td>';
	echo '<td>'.$product->stock.'</td>';
	echo '<td>'.$product->price.'</td>';
	echo '<td>';
	echo Html::a('<i class="glyphicon glyphicon-pencil"></i>',['product/update','id'=>$product->id]);
	echo Html::a('<i class="glyphicon glyphicon-trash"></i>',['product/delete','id'=>$product->id],['onclick'=>'return(confirm("Apakah data mau dihapus?") ? true : false);', 'style'=>'margin-left:10px;']);
	echo '</td>';
	echo '</tr>';
}
echo '</table>';