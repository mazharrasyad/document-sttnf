<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
?>
<h1>Update Customer</h1>
<?php $form = ActiveForm::begin(); ?>
	
	<?= $form->field($model,'firstname') ?>
	<?= $form->field($model,'lastname') ?>
	<?= $form->field($model,'phone') ?>
	<?= $form->field($model,'address')->textarea() ?>
	<?= Html::submitButton('Ubah',['class'=>'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>