<?php
use yii\helpers\Html;
?>
<h1>Daftar Order</h1>
<?php
echo Html::a('Create',['create'],['class'=>'btn btn-primary', 'style'=>'margin-bottom:5px;']);
echo '<table class="table table-bordered table-striped">';
echo '<tr>';
echo '<th>ID</th>';
echo '<th>ORDER DATE</th>';
echo '<th>CUSTOMERS ID</th>';
echo '<th>ACTION</th>';
echo'</tr>';
foreach ($orders as $order) {
	echo '<tr>';
	echo '<td>'.$order->id.'</td>';
	echo '<td>'.$order->order_date.'</td>';
	echo '<td>'.$order->customers_id.'</td>';
	echo '<td>';
	echo Html::a('<i class="glyphicon glyphicon-pencil"></i>',['order/update','id'=>$order->id]);
	echo Html::a('<i class="glyphicon glyphicon-trash"></i>',['order/delete','id'=>$order->id],['onclick'=>'return(confirm("Apakah data mau dihapus?") ? true : false);', 'style'=>'margin-left:10px;']);
	echo '</td>';
	echo '</tr>';
}
echo '</table>';