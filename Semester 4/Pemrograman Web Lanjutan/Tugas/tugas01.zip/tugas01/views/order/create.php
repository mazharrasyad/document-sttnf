<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use dosamigos\datepicker\DatePicker;

$customers_id = ArrayHelper::map(\app\models\Customer::find()->asArray()->all(), 'id', 'firstname');

?>
<h1>Create Order</h1>
<?php $form = ActiveForm::begin(); ?>
	
	<?= $form->field($model,'order_date')->widget(
    DatePicker::className(), [
        // inline too, not bad
        'inline' => false, 
        // modify template for custom rendering
        //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
        'clientOptions' => [
            'autoclose' => true,
            'format' => 'yyyy-mm-dd'
        ]
	]);?>
	<?= $form->field($model,'customers_id')->dropDownList($customers_id, ['prompt' => 'Pilih Customer','class' => 'form-control'])->label('Customer') ?>
	<?= Html::submitButton('Simpan',['class'=>'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>