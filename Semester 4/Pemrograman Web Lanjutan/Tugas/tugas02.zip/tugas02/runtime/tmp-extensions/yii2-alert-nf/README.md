yii2-alert-nf
=============
Widget Alert twitter bootstrap for Yii Framework2

Installation
------------

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

Either run

```
php composer.phar require --prefer-dist mazharrasyad/yii2-alert-nf "*"
```

or add

```
"mazharrasyad/yii2-alert-nf": "*"
```

to the require section of your `composer.json` file.


Usage
-----

Once the extension is installed, simply use it in your code by  :

```php
<?= \mazharrasyad\alert\AutoloadExample::widget(); ?>```