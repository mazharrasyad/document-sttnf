<?php

return [
    'adminEmail' => 'admin@example.com',
    'icon-framework' => \kartik\icons\Icon::FAS,  // Font Awesome Icon framework
];
