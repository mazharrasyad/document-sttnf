<?php
use hscstudio\chart\ChartNew;
/* @var $this yii\web\View */

$this->title = 'Praktikum 03 PWL';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Praktikum 03</h1>

        <p class="lead">Pemrograman Web Lanjutan</p>

        <i>Happy Coding :D</i>
    </div>

    <div class="body-content text-center">
      <?= \kartik\icons\Icon::show('laptop-code', ['class' => 'fa-5x']) ?>
      <?php \insolita\wgadminlte\LteBox::begin([
              'type'=>\insolita\wgadminlte\LteConst::TYPE_INFO,
              'isSolid'=>true,
              'boxTools'=>'<button class="btn btn-success btn-xs create_button" ><i class="fa fa-plus-circle"></i> Add</button>',
              'tooltip'=>'this tooltip description',
              'title'=>'Manage users',
              'footer'=>'total 44 active users',
          ])?>
        ANY BOX CONTENT HERE
      <?php \insolita\wgadminlte\LteBox::end()?>
      <?php echo \insolita\wgadminlte\LteInfoBox::widget([
                      'bgIconColor'=>\insolita\wgadminlte\LteConst::COLOR_AQUA,
                      'bgColor'=>'',
                      'number'=>100500,
                      'text'=>'Test Three',
                      'icon'=>'fa fa-bolt',
                      'showProgress'=>true,
                      'progressNumber'=>66,
                      'description'=>'Something about this'
                  ])?>
    </div>
</div>
