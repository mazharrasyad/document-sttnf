# PRAKTIKUM 03

Latihan cara membuat Module & menggunakan Extension pada Yii2

## Tahapan Memulai

Clone project ini pada folder web-lanjut-sttnf-20182-ti1

```
git clone -b master https://gitlab.com/web-lanjut-sttnf-20182-ti1/praktikum03.git
```

Setelah clone selesai, copy folder **vendor** yang diberikan pada saat latihan

### Buat Branch

Masuk ke folder **praktikum03**, lalu buat branch baru dengan format *[NIM_NAMA]*

```
cd praktikum03
```

Contoh buat branch:

```
git checkout -b 0110217034_fikri
```
