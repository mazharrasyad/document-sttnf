-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 22 Jul 2019 pada 10.18
-- Versi server: 10.3.15-MariaDB
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbgii_ti1`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth`
--

CREATE TABLE `auth` (
  `module` varchar(60) NOT NULL,
  `controller` varchar(60) NOT NULL,
  `action` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `auth`
--

INSERT INTO `auth` (`module`, `controller`, `action`, `user_id`, `id`) VALUES
('master', 'category', 'index', 1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('ADMINISTRATOR', '1', 1562041201);

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/*', 2, NULL, NULL, NULL, 1562040141, 1562040141),
('/admin/*', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/assignment/*', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/assignment/assign', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/assignment/index', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/assignment/revoke', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/assignment/view', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/default/*', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/default/index', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/menu/*', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/menu/create', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/menu/delete', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/menu/index', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/menu/update', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/menu/view', 2, NULL, NULL, NULL, 1562040131, 1562040131),
('/admin/permission/*', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/assign', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/create', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/delete', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/index', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/remove', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/update', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/permission/view', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/role/*', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/role/assign', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/role/create', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/role/delete', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/role/index', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/role/remove', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/role/update', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/role/view', 2, NULL, NULL, NULL, 1562040132, 1562040132),
('/admin/route/*', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/route/assign', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/route/create', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/route/index', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/route/refresh', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/route/remove', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/*', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/create', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/delete', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/index', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/update', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/rule/view', 2, NULL, NULL, NULL, 1562040133, 1562040133),
('/admin/user/*', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/activate', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/change-password', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/delete', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/index', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/login', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/logout', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/request-password-reset', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/reset-password', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/signup', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/admin/user/view', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/debug/*', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/*', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/db-explain', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/download-mail', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/index', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/toolbar', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/default/view', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/user/*', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/user/reset-identity', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/debug/user/set-identity', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/gii/*', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/*', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/action', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/diff', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/index', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/preview', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/gii/default/view', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/master/*', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/master/category/*', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/category/create', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/category/delete', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/category/index', 2, NULL, NULL, NULL, 1562040134, 1562040134),
('/master/category/update', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/category/view', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/*', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/create', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/delete', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/index', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/update', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/city/view', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/master/default/*', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/master/default/index', 2, NULL, NULL, NULL, 1562040135, 1562040135),
('/site/*', 2, NULL, NULL, NULL, 1562040141, 1562040141),
('/site/about', 2, NULL, NULL, NULL, 1562040141, 1562040141),
('/site/captcha', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/site/contact', 2, NULL, NULL, NULL, 1562040141, 1562040141),
('/site/error', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/site/index', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/site/login', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/site/logout', 2, NULL, NULL, NULL, 1562040140, 1562040140),
('/user/*', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/user/admin/*', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/admin/assignments', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/block', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/admin/confirm', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/create', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/delete', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/index', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/info', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/resend-password', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/admin/switch', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/update', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/admin/update-profile', 2, NULL, NULL, NULL, 1562040136, 1562040136),
('/user/profile/*', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/profile/index', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/profile/show', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/recovery/*', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/recovery/request', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/recovery/reset', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/registration/*', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/registration/confirm', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/registration/connect', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/registration/register', 2, NULL, NULL, NULL, 1562040137, 1562040137),
('/user/registration/resend', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/security/*', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/security/auth', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/security/login', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/security/logout', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/settings/*', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/user/settings/account', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/settings/confirm', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('/user/settings/delete', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/user/settings/disconnect', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/user/settings/networks', 2, NULL, NULL, NULL, 1562040139, 1562040139),
('/user/settings/profile', 2, NULL, NULL, NULL, 1562040138, 1562040138),
('ADMINISTRATOR', 1, 'Administrator', NULL, NULL, 1562041066, 1562041066),
('basic user', 2, 'All of basic actions for user authenticated', NULL, NULL, 1562040548, 1562040797),
('modul master data', 2, 'Modul Master Data', NULL, NULL, 1562041506, 1562041506),
('rbac manager', 2, 'RBAC Manager', NULL, NULL, 1562040813, 1562040813),
('user manager', 2, 'User Manager', NULL, NULL, 1562040896, 1562040896);

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('ADMINISTRATOR', 'basic user'),
('ADMINISTRATOR', 'modul master data'),
('ADMINISTRATOR', 'rbac manager'),
('ADMINISTRATOR', 'user manager'),
('basic user', '/user/profile/*'),
('basic user', '/user/security/logout'),
('basic user', '/user/settings/*'),
('modul master data', '/master/*'),
('rbac manager', '/admin/*'),
('user manager', '/user/admin/*');

-- --------------------------------------------------------

--
-- Struktur dari tabel `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `province_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `city`
--

INSERT INTO `city` (`id`, `name`, `province_id`) VALUES
(1, 'Jakarta Barat', 1),
(2, 'Jakarta Timur', 1),
(3, 'Bandung', 2),
(4, 'Tanggerang', 2),
(5, 'Jakarta Pusat', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1561431895),
('m140209_132017_init', 1561431900),
('m140403_174025_create_account_table', 1561431902),
('m140504_113157_update_tables', 1561431910),
('m140504_130429_create_token_table', 1561431913),
('m140506_102106_rbac_init', 1562039239),
('m140830_171933_fix_ip_field', 1561431915),
('m140830_172703_change_account_table_name', 1561431916),
('m141222_110026_update_ip_field', 1561431918),
('m141222_135246_alter_username_length', 1561431919),
('m150614_103145_update_social_account_table', 1561431920),
('m150623_212711_fix_username_notnull', 1561431920),
('m151218_234654_add_timezone_to_profile', 1561431921),
('m160929_103127_add_last_login_at_to_user_table', 1561431921),
('m170907_052038_rbac_add_index_on_auth_assignment_user_id', 1562039239),
('m180523_151638_rbac_updates_indexes_without_prefix', 1562039240);

-- --------------------------------------------------------

--
-- Struktur dari tabel `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `profile`
--

INSERT INTO `profile` (`user_id`, `name`, `public_email`, `gravatar_email`, `gravatar_id`, `location`, `website`, `bio`, `timezone`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `province`
--

CREATE TABLE `province` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `province`
--

INSERT INTO `province` (`id`, `name`) VALUES
(1, 'Jakarta'),
(2, 'Jawa Barat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `social_account`
--

CREATE TABLE `social_account` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `token`
--

CREATE TABLE `token` (
  `user_id` int(11) NOT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  `type` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `token`
--

INSERT INTO `token` (`user_id`, `code`, `created_at`, `type`) VALUES
(1, 'LYcNLeGH5eqZNueSzRHtknGncALc4J3Y', 1561431927, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `confirmed_at` int(11) DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blocked_at` int(11) DEFAULT NULL,
  `registration_ip` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  `last_login_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `auth_key`, `confirmed_at`, `unconfirmed_email`, `blocked_at`, `registration_ip`, `created_at`, `updated_at`, `flags`, `last_login_at`) VALUES
(1, 'admin', 'muhazharrasyad@gmail.com', '$2y$12$9BR0y6u.Tj.Zf0wxLHOxLePoBMN50NWksO.W8C4FqIE19ZXE4URXq', 'xrA3hwxaWp60mJRcgRJQoRx1z9nEvNzj', NULL, NULL, NULL, '127.0.0.1', 1561431927, 1561431927, 0, 1563504893);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`),
  ADD KEY `idx-auth_assignment-user_id` (`user_id`);

--
-- Indeks untuk tabel `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Indeks untuk tabel `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indeks untuk tabel `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indeks untuk tabel `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `province_id` (`province_id`);

--
-- Indeks untuk tabel `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indeks untuk tabel `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Indeks untuk tabel `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `social_account`
--
ALTER TABLE `social_account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_unique` (`provider`,`client_id`),
  ADD UNIQUE KEY `account_unique_code` (`code`),
  ADD KEY `fk_user_account` (`user_id`);

--
-- Indeks untuk tabel `token`
--
ALTER TABLE `token`
  ADD UNIQUE KEY `token_unique` (`user_id`,`code`,`type`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_unique_username` (`username`),
  ADD UNIQUE KEY `user_unique_email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `province`
--
ALTER TABLE `province`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `social_account`
--
ALTER TABLE `social_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `province_id` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`);

--
-- Ketidakleluasaan untuk tabel `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `fk_user_profile` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `social_account`
--
ALTER TABLE `social_account`
  ADD CONSTRAINT `fk_user_account` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `token`
--
ALTER TABLE `token`
  ADD CONSTRAINT `fk_user_token` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
