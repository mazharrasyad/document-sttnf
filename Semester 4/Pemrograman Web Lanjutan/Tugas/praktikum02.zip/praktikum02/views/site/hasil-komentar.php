<?= '<p>Nama: '.$model->nama.'</p>' ?>
<?= '<p>Pesan: '.$model->pesan.'</p>' ?>