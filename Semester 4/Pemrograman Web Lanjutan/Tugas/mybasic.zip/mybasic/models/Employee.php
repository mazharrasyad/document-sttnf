<?php

namespace app\models;

use yii\db\ActiveRecord;

class Employee extends ActiveRecord 
{
  public static function tablename()
  {
    return 'employee';
  }
}
