<?php
use yii\helpers\Html;
?>

<h1>Daftar Pegawai</h1>

<?php
echo Html::a('Create',['create'],['class' => 'btn btn-primary', 'style' => 'margin-bottom:5px;']);
echo '<table class="table table-bordered table-striped">';
echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>NIP</th>';
    echo '<th>Nama</th>';
    echo '<th>Gender</th>';
    echo '<th>ID Agama</th>';
    echo '<th>ID Divisi</th>';
    echo '<th>ID Jabatan</th>';
    echo '<th>Action</th>';
echo '</tr>';
foreach($pegawais as $pegawai)
{
    echo '<tr>';
        echo '<td>'.$pegawai->id.'</td>';
        echo '<td>'.$pegawai->nip.'</td>';
        echo '<td>'.$pegawai->nama.'</td>';
        echo '<td>'.$pegawai->gender.'</td>';
        echo '<td>'.$pegawai->id_agama.'</td>';
        echo '<td>'.$pegawai->id_divisi.'</td>';
        echo '<td>'.$pegawai->id_jabatan.'</td>';
        echo '<td>';
            echo Html::a('<i class="glyphicon glyphicon-pencil"></i>',[
                'pegawai/update', 
                'id' => $pegawai->id]
            );
            echo Html::a('<i class="glyphicon glyphicon-trash"></i>',[
                'pegawai/delete', 
                'id' => $pegawai->id],[
                'onclick' => 'return(confirm("Apakah data mau dihapus ?") ? true : false);',
                'style' => 'margin-left:10px;']);
        echo '</td>';
    echo '</tr>';
}
echo '</table>';