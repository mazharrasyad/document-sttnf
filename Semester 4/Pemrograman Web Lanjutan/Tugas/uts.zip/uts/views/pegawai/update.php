<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;

$id_agama = ArrayHelper::map(\app\models\Agama::find()->asArray()->all(), 'id', 'nama');
$id_divisi = ArrayHelper::map(\app\models\Divisi::find()->asArray()->all(), 'id', 'nama');
$id_jabatan = ArrayHelper::map(\app\models\Jabatan::find()->asArray()->all(), 'id', 'nama');

?>

<h1>Update Pegawai</h1>

<?php $form = ActiveForm::begin() ?>

<?= $form->field($model, 'nip') ?>
<?= $form->field($model, 'nama') ?>
<?= $form->field($model, 'gender')->radioList(['L' => 'Laki-Laki', 'P' => 'Perempuan']) ?>
<?= $form->field($model, 'id_agama')->dropDownList($id_agama, ['prompt' => 'Pilih Agama','class' => 'form-control'])->label('Agama') ?>
<?= $form->field($model, 'id_divisi')->dropDownList($id_divisi, ['prompt' => 'Pilih Divisi','class' => 'form-control'])->label('Divisi') ?>
<?= $form->field($model, 'id_jabatan')->dropDownList($id_jabatan, ['prompt' => 'Pilih Jabatan','class' => 'form-control'])->label('Jabatan') ?>
<?= Html::submitButton('Ubah',['class'=>'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>