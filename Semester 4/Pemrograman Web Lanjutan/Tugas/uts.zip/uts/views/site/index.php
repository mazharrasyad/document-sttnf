<?php

/* @var $this yii\web\View */

$this->title = 'UTS PWL 20182';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Selamat Mengerjakan UTS</h1>

        <p class="lead">Pemrograman Web Lanjutan</p>

        <i>Happy Coding :D</i>
    </div>

    <div class="body-content">
    </div>
</div>
