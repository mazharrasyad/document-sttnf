<?php

namespace app\models;

use yii\db\ActiveRecord;

class Pegawai extends ActiveRecord 
{
    public static function tableName()
    {
        return 'pegawai';
    }

    public function rules()
    {
        return [
            [['nip','nama','gender','id_agama','id_divisi','id_jabatan'], 'required'],
            [['nip','nama','gender'], 'string'],
            [['id_agama','id_divisi','id_jabatan'], 'integer'],
        ];
    }
}