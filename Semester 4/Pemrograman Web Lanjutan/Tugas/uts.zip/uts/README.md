# UTS PWL

Project ini digunakan untuk pengumpulan jawaban UTS Pemrograman Web Lanjutan.

## Aturan Ujian

- Batas waktu pengumpulan (push commit) jawaban ujian sampai dengan **23 April 2019 11:15**

- Dilarang keras melakukan copy paste pekerjaan teman

## Tahapan Memulai

Clone project ini pada folder web-lanjut-sttnf-20182-ti1

```
git clone -b master https://gitlab.com/web-lanjut-sttnf-20182-ti1/uts.git
```

Setelah clone selesai, copy folder **vendor** pada project *mybasic* ke folder *uts*

### Buat Branch

Masuk ke folder **uts**, lalu buat branch baru dengan format *[NIM_NAMA]*

```
cd uts
```

Contoh buat branch:

```
git checkout -b 0110217034_fikri
```

### Buat Database & Import

- Buatlah database **dbkepegawaian** pada phpMyAdmin
- Lakukan import file [**dbkepegawaian.sql**](https://gitlab.com/web-lanjut-sttnf-20182-ti1/uts/blob/master/dbkepegawaian.sql) yang ada pada project ini ke database dbkepegawaian

Tahapan selesai, silahkan kerjakan soalnya.
