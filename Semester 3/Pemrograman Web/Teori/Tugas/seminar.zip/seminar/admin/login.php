<?php
    include_once ("top.php");
?>

<div class="row">
    <div class="col-md-12">
        
    <form role="form">
				<div class="form-group">
					 
					<label for="exampleInputEmail1">
						Email address
					</label>
					<input class="form-control" id="exampleInputEmail1" type="email" />
				</div>
				<div class="form-group">
					 
					<label for="exampleInputPassword1">
						Password
					</label>
					<input class="form-control" id="exampleInputPassword1" type="password" />
				</div>
				<div class="form-group">
					 
					<label for="exampleInputFile">
						File input
					</label>
					<input class="form-control-file" id="exampleInputFile" type="file" />
					<p class="help-block">
						Example block-level help text here.
					</p>
				</div>
				<div class="checkbox">
					 
					<label>
						<input type="checkbox" /> Check me out
					</label>
				</div> 
				<button type="submit" class="btn btn-primary">
					Submit
				</button>
			</form>

    </div>
</div>

<?php
    include_once ("bottom.php");
?>