<?php
    $buahs = ["Pepaya","Mangga","Pisang","Jambu"];

    foreach($buahs as $b)
    {
        echo $b;
        echo '<br>';
    }
    echo '<hr>';
    foreach($buahs as $k => $v)
    {
        echo 'Index buah ' . $k . ' adalah ' . $v;
        echo '<br>';
    }
?>    

<form>
    Buah pilihan :
    <select name="buah">
        <?php
            foreach($buahs as $k => $v)
            {
                echo '<option value="'.$k.'">'.$v.'</option>';
            }
        ?>
    </select>
</form>