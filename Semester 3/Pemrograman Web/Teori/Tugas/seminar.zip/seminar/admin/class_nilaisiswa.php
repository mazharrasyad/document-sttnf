<?php

class NilaiSiswa
{
    public $nama;
    public $nilai;
    public $sekolah = 'SDIT NF';    

    public function __construct($nama, $nilai)
    {
        $this->nama = $nama;
        $this->nilai = $nilai;
    }

    public function getHasil()
    {
        if($this->nilai > 55) 
            return 'Lulus';
        else 
            return 'Nggak Lulus';
    }
}

$ns1 = new NilaiSiswa('Faiz Fikri', 80);
// $ns1->nama = 'Faiz Fikri';
// $ns1->nilai = 80;
echo $ns1->nama . '<br> Sekolah di ' . $ns1->sekolah;
echo '<br>' . $ns1->nama . ' Dinyatakan' . $ns1->getHasil();

?>