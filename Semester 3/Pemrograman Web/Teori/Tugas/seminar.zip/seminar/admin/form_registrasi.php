<?php
    include_once ("top.php");
?>

<form method="POST" action="proses_registrasi.php">
  <div class="form-group row">
    <label for="nama" class="col-4 col-form-label">Nama</label> 
    <div class="col-8">
      <input id="nama" name="nama" type="text" class="form-control here" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-4 col-form-label">Email</label> 
    <div class="col-8">
      <input id="email" name="email" type="text" class="form-control here" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="telp" class="col-4 col-form-label">Telp / HP</label> 
    <div class="col-8">
      <input id="telp" name="telp" type="text" class="form-control here" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Status</label> 
    <div class="col-8">
      <label class="custom-control custom-radio">
        <input name="status" type="radio" class="custom-control-input" value="1" required="required"> 
        <span class="custom-control-indicator"></span> 
        <span class="custom-control-description">Mahasiswa</span>
      </label>
      <label class="custom-control custom-radio">
        <input name="status" type="radio" class="custom-control-input" value="2" required="required"> 
        <span class="custom-control-indicator"></span> 
        <span class="custom-control-description">Pelajar</span>
      </label>
      <label class="custom-control custom-radio">
        <input name="status" type="radio" class="custom-control-input" value="3" required="required"> 
        <span class="custom-control-indicator"></span> 
        <span class="custom-control-description">Umum</span>
      </label>
    </div>
  </div>
  <div class="form-group row">
    <label for="alasan" class="col-4 col-form-label">Alasan</label> 
    <div class="col-8">
      <textarea id="alasan" name="alasan" cols="40" rows="5" class="form-control" required="required"></textarea>
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
    <input name="submit" type="submit" class="btn btn-warning" value="Kirim"/>
    </div>
  </div>
</form>

<?php
    include_once ("bottom.php");
?>