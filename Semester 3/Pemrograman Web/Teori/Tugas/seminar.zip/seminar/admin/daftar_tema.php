<?php
include_once ("dbkoneksi.php");

//siapkan query
$sql = "select * from tema";

//eksekusi query, simpan di resultset 
$rs = $dbh->query($sql);

//tampilkan data dari resultset
foreach($rs as $row){
    echo '<br/>'. $row['id'].' --- '.$row['nama'];
}

?>