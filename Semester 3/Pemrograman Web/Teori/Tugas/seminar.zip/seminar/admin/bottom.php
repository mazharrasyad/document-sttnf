    <div class="row">
        <div class="col-md-12">
          
          <address>
                    <strong>Twitter, Inc.</strong><br> 
                    795 Folsom Ave, Suite 600<br> 
                    San Francisco, CA 94107<br> 
                    <abbr title="Phone">P:</abbr> (123) 456-7890
          </address>
        </div>
      </div>
    </div>
  </body>
</html>