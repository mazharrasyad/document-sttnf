<?php
include_once 'class_DAO.php';

class Tema {
  private $dbh;
  private $tblName = "tema";

  public function __construct() {
    $this->dbh=DAO::getInstance();
  }

  public function getALL() {
    $sql= "select * from ".$this->tblName;
    $rs = $this->dbh->query($sql);
    return $rs;
  }

}

 ?>
