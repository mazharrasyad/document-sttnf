<?php
    $nama = 'Ilham Santoso';
    $alamat = 'Cipayung City';
    $umur = '20';
    $berat = 53.20;
    $lulus = FALSE;
?>

Nama Mahasiswa : <?php echo $nama ?> <br>
<!-- < ?= sama dengan < ?php echo  -->
Alamat : <?= $alamat ?> <br> 
Umur : <?php echo $umur ?> <br>
<?php echo 'Berat : ' . $berat . ' Kg'; ?> <br>
<?php 
    if($lulus) 
    { 
        echo 'Sudah Lulus';
    }
    else 
    {
        echo 'Belum Lulus';
    }
?>
<hr>
<?php
    echo 'DOKUMEN ROOT ' . $_SERVER['DOCUMENT_ROOT'];
    echo '<br>';
    echo 'NAMA FILE : ' . $_SERVER['PHP_SELF'];
?>
<hr>
<?php
    echo 'NAMA SISWA $nama';
    echo '<br>';
    echo "NAMA SISWA $nama";
    echo '<br>';
    echo "NAMA SISWA $namas";
?>
