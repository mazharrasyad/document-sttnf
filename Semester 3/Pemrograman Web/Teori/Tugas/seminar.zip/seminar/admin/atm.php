<?php

require_once 'class_account.php';
require_once 'class_bankaccount.php';

$ac1 = new Account("0200",4000);
$ac1->cetak();
$ac1->deposit(568);
$ac1->cetak();

?>

<hr>

<?php

$ab1 = new BankAccount("0301",5000,"Fellani");
$ab2 = new BankAccount("0402",2000,"Rashford");
$ab1->cetak();
echo '<br>';
$ab2->cetak();
// Fellani transfer ke rashford $560
$ab1->transfer($ab2,560);
echo '<hr>';
$ab1->cetak();
echo '<br>';
$ab2->cetak();

?>