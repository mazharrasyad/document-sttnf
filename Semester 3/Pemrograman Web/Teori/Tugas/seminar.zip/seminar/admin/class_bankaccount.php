<?php
require_once 'class_account.php';

class BankAccount extends Account
{
    private $customer;

    public function __construct($no, $saldo, $cust)
    {
        // Panggil parent class constructor
        parent::__construct($no, $saldo);
        $this->customer = $cust;
    }
    
    // Overriding method parent class
    public function cetak()
    {
        parent::cetak();
        echo ' Customer : ' . $this->customer;
    }

    public function transfer($ac_tujuan, $uang)
    {
        $ac_tujuan->deposit($uang);
        // Panggil method dari parent class
        $this->withdraw($uang);
    }
}

?>