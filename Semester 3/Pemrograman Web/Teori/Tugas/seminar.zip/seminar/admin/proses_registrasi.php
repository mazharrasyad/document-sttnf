<?php
    include_once ("top.php");
?>

<div class="row">
    <div class="col-md-12">
        
        <?php
            // Tangkap request form
            $_nama = $_POST['nama'];
            $_email = $_POST['email'];
            $_telp = $_POST['telp'];
            $_status = $_POST['status'];
            $_alasan = $_POST['alasan'];          
        ?>
        <ul>
            <li>Nama : <?= $_nama ?></li>
            <li>Email : <?= $_email ?></li>
            <li>Telp / HP : <?= $_telp ?></li>
            <li>Status : <?= $_status ?></li>
            <li>Alasan : <?= $_alasan ?></li>
    </div>
</div>

<?php
    include_once ("bottom.php");
?>