<?php

class Matematika
{
    // Member class variable constanta
    const PHI = 3.14;

    // Member static variable
    public static $counter = 100;

    // Member static function
    public static function naikanCounter()
    {
        self::$counter++;
    }

    public static function luasLingkaran($jari)
    {
        $luas = self::PHI * $jari * $jari;
        return $luas;
    }
}

?>
