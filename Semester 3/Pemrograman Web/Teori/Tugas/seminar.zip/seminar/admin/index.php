<?php
    include_once ("top.php");
?>

<div class="row">
    <div class="col-md-12">
        
        <h1>Selamat Datang di Administrator</h1>

    </div>
</div>

<?php
    include_once ("bottom.php");
?>