<?php
try{
    $host = 'localhost';
    $dbname = 'dbseminar';
    $dbuser = 'ti1';
    $dbpass = 'ti1';
    $dbport = '5432';

    $dbh = new PDO("pgsql:host=$host;dbname=$dbname;port=$dbport",$dbuser,$dbpass);
    $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
    echo $e->getMessage();
}
?>
