<?php

// Library menggunakan require_once bukan include_once seperti class
require_once 'class_matematika.php';

echo 'Counter : ' . Matematika::$counter;
Matematika::naikanCounter();
echo '<br>Counter : ' . Matematika::$counter;
echo '<br/>Nilai PHI : ' . Matematika::PHI;

$jari = 8;
$luasling = Matematika::luasLingkaran($jari);
echo '<br>Luas Lingkaran Jari2 8 ' . $luasling;
?>
