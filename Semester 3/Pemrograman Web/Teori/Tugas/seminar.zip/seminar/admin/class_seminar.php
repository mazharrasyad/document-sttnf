<?php
include_once 'class_DAO.php';

class seminar {
  private $dbh;
  private $tblName = "seminar";

  public function __construct() {
    $this->dbh=DAO::getInstance();
  }

  public function getALL() {
    $sql= "select *from ".$this->tblName;
    $rs = $this->dbh->query($sql);
    return $rs;
  }

  public function simpan($data) {
    $sql = "insert into seminar(kode,judul,pembicara,tanggal,tempat,biaya,status,tema_id) 
    values(?,?,?,?,?,?,?,?)";
    $st = $this->dbh->prepare($sql);
    $st->execute($data);
  }

  public function update($data) {
    $sql = "update seminar set kode=?,judul=?,pembicara=?,tanggal=?,
            tempat=?,biaya=?,status=?,tema_id=? where id=?";
    $st = $this->dbh->prepare($sql);
    $st->execute($data);
  }

  public function hapus($id) {
    $sql = "delete from seminar where id = ?";
    $st = $this->dbh->prepare($sql);
    $st->execute([$id]);
  }

  public function findByID($id){
    $sql = "select * from seminar where id = ?";
    $st = $this->dbh->prepare($sql);
    $st->execute(array($id));
    $row = $st->fetch();
    return $row;
  }
}

 ?>
