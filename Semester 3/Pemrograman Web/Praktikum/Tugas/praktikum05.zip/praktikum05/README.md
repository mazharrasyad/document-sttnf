# Praktikum05

Javascript2