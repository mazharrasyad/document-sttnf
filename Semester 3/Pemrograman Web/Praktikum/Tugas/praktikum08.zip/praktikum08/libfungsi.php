<?php
    function kelulusan($_nilai)
    {
        if($_nilai > 55){
            return 'Lulus';
        } else{
            return 'Tidak Lulus';
        }
    }

    function grade($_nilai)
    {
        if($_nilai < 0){
            return 'I';
        } else if($_nilai < 36){
            return 'E';
        } else if($_nilai < 56){
            return 'D';
        } else if($_nilai < 70){
            return 'C';
        } else if($_nilai < 85){
            return 'B';
        } else if($_nilai < 101){
            return 'A';
        } else{
            return 'I';
        }
    }

    function predikat($_grade)
    {
        if($_grade == 'E'){
            return 'Sangat Kurang';
        } else if($_grade == 'D'){
            return 'Kurang';
        } else if($_grade == 'C'){
            return 'Cukup';
        } else if($_grade == 'B'){
            return 'Memuaskan';
        } else if($_grade == 'A'){
            return 'Sangat Memuaskan';
        } else{
            return 'Tidak Ada';
        }
    }
?>