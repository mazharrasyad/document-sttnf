<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SAS-STTNF</title>
</head>
<body>
    
    <header role="banner">
        <h2>Student Activity Score - STTNF</h2>
        <a href="#">Home</a> | 
        <a href="#">Activity</a> |
        <a href="form_nilai.php">My Score</a> |
        <a href="#">Login</a>
    </header>