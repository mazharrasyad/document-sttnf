<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<form class="form-horizontal" method="POST" action="form_belanja.php">
<fieldset>

<!-- Form Name -->
<legend>Belanja Online</legend>

<div class="col-md-8">

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="customer">Customer</label>  
  <div class="col-md-5">
  <input id="customer" name="customer" type="text" placeholder="Nama Customer" class="form-control input-md">
    
  </div>
</div>

<!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="produk">Pilih Produk</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="produk-0">
      <input type="radio" name="produk" id="produk-0" value="TV" checked="checked">
      TV
    </label> 
    <label class="radio-inline" for="produk-1">
      <input type="radio" name="produk" id="produk-1" value="Kulkas">
      Kulkas
    </label> 
    <label class="radio-inline" for="produk-2">
      <input type="radio" name="produk" id="produk-2" value="Mesin Cuci">
      Mesin Cuci
    </label>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="jumlah">Jumlah</label>  
  <div class="col-md-4">
  <input id="jumlah" name="jumlah" type="text" placeholder="Jumlah" class="form-control input-md">
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="proses"></label>
  <div class="col-md-4">
    <button id="proses" name="proses" class="btn btn-success" value="Kirim">Kirim</button>
  </div>
</div>

</div>

<div class="col-md-4">
    <div class="panel panel-default">
        <div class="panel-body bg-primary">
            Daftar Harga
        </div>

        <div class="panel-body">
            TV : 4.200.000
        </div>

        <div class="panel-body">
            Kulkas : 3.100.000
        </div>

        <div class="panel-body">
            Mesin Cuci : 3.800.000
        </div>

        <div class="panel-body bg-primary">
            Harga Dapat Berubah Setiap Saat
        </div>
    </div>
</div>

</fieldset>
</form>

<?php
    $proses = $_POST['proses'];
    $customer = $_POST['customer'];
    $produk = $_POST['produk'];
    $jumlah = $_POST['jumlah'];

    if($produk == 'TV')
        $total = 4200000 * $jumlah;
    else if($produk == 'Kulkas')
        $total = 3100000 * $jumlah;
    else if($produk == 'Mesin Cuci')
        $total = 3800000 * $jumlah;

    echo 'Nama Customer : ' . $customer;
    echo '<br>Produk Pilihan : ' . $produk;
    echo '<br>Jumlah Beli : ' . $jumlah;
    echo '<br>Total Belanja : Rp ' . $total;
?>
