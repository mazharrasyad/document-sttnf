public class DemoBankAccount{
	public static void main(String ar[]){
		//instantiation --> membuat instance(obj)
		//masak
		BankAccount b1 = new BankAccount();
		BankAccount b2 = new BankAccount("Hilmi");
		BankAccount b3 = b1;

		//deposit
		b1.deposit(99.99);
		b2.deposit(100.50);
		b3.deposit(45.765);

		//cek saldo
		//double saldob1 = b1.getBalance();

		//System.out.println("Saldo b1:"+saldob1);
		System.out.println("Saldo b1:"+b1.getBalance());
		System.out.println("Saldo b2:"+b2.getBalance());
		System.out.println("Saldo b3:"+b3.getBalance());
		//transfer
		b1.transfer(300,b2);
		//print detail
		b1.printDetail();


	}
}
