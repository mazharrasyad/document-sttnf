public class BankAccount{
	//property --> punya apa?
	private double balance;
	private String name; //1. hauzani
	//method --> bisa apa?
	public double getBalance(){
		return balance;
	}
	public void deposit(double amount){
		balance = balance + amount;
	}
	//3 yazid
	public void printDetail(){
		System.out.println("Name:"+name);
		System.out.println("Balance:"+balance);
	}
	//5 everet & rizal
	public void transfer(double amount,BankAccount dest){
		//saldo kita dikurangi jumlah
		balance = balance - amount;
		//saldo tujuan bertambah
		dest.deposit(amount);
	}


	//constructor
	public BankAccount(){
		balance = 0;
		name = "fulan";//2. ahmad mairat
	}
	//overload 4. Auzan
	public BankAccount(String mName){
		name = mName;
		balance = 0;
	}

}
