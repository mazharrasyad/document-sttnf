public class HelloPrinter
{
  public static void main(String [] args)
  {
    System.out.println("........................................");
    System.out.println("|  ..................................  |");
    System.out.println("|  |   _____    _______    ______   |  |");
    System.out.println("|  |  |  _  |  |   _   |  |  __  |  |  |");
    System.out.println("|  |  | |_| |  |  |_| _|  | |  | |  |  |");
    System.out.println("|  |  |   __|  |   _ |_   | |  | |  |  |");
    System.out.println("|  |  |  |     |  |_|  |  | |__| |  |  |");
    System.out.println("|  |  |__|     |_______|  |______|  |  |");
    System.out.println("|  |                                |  |");
    System.out.println("|  ..................................  |");
    System.out.println("........................................");
  }
}
